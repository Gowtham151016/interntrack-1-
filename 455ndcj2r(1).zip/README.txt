INTERNTRACK - COLLEGE INTERNSHIP PORTAL
=====================================

This version is designed to run in restricted PHP environments such as ByteXL
where mysqli/pdo_mysql may not be installed. It therefore uses a lightweight
JSON datastore in data/ and requires no database PHP extension.

FEATURES
- Student and Company registration/login
- Password hashing and session authentication
- Student profile + PDF resume upload (5 MB max)
- Internship search by keyword/location
- Internship application and duplicate protection
- Student application tracking
- Company internship publishing
- Open/Closed internship control
- Applicant status management
- Responsive modern UI

RUN
1. Extract the project.
2. Make sure the project parent folder and uploads/ folder are writable by PHP. The app creates a private `interntrack_data/` folder automatically.
3. Start: php -S 0.0.0.0:8080 -t internship-portal
4. Open the ByteXL forwarded URL.
5. Register a Student and a Company account and test the workflow.

The original MySQL connection details remain in config/database.php for future
migration to MySQL, but this portable build does not call mysqli, mysqli_report,
or pdo_mysql, so the missing-extension 500 error is removed.
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap');

:root{--bg:#111214;--panel:#202124;--panel2:#292a2d;--text:#f5f5f5;--muted:#b0b3b8;--line:rgba(255,255,255,.12);--primary:#8b8d91;--primary2:#e0e0e0;--success:#8ec7a1;--danger:#ff8585;--warning:#e7c778;--shadow:0 24px 80px rgba(0,0,0,.45)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(circle at 15% 0%,rgba(255,255,255,.07),transparent 32%),radial-gradient(circle at 90% 15%,rgba(150,150,150,.08),transparent 28%),var(--bg);color:var(--text);font-family:Inter,system-ui,sans-serif;min-height:100vh}a{color:inherit;text-decoration:none}.navbar{height:76px;padding:0 5%;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line);background:rgba(17,18,20,.88);backdrop-filter:blur(18px);position:sticky;top:0;z-index:20}.logo{font:700 24px 'Space Grotesk',sans-serif;letter-spacing:-1px}.logo span{color:var(--primary2)}.nav-links{display:flex;align-items:center;gap:25px;color:var(--muted);font-size:13px}.nav-links a:hover{color:#fff}.nav-button{background:linear-gradient(135deg,#55575b,#85878b);padding:11px 17px;border-radius:10px;color:#fff!important;box-shadow:0 10px 25px rgba(124,92,255,.25)}
.hero{max-width:1250px;margin:auto;padding:100px 5% 85px;display:grid;grid-template-columns:1.15fr .85fr;gap:70px;align-items:center}.eyebrow{font-size:11px;font-weight:800;letter-spacing:2px;color:var(--primary2);margin:0 0 14px}.hero h1{font:700 clamp(48px,6vw,78px)/1.02 'Space Grotesk',sans-serif;letter-spacing:-4px;margin:0 0 25px}.hero h1 span{background:linear-gradient(90deg,var(--primary),var(--primary2));-webkit-background-clip:text;background-clip:text;color:transparent}.hero-text{max-width:650px;color:var(--muted);font-size:17px;line-height:1.8}.hero-buttons{display:flex;gap:12px;margin-top:32px}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:11px;padding:13px 18px;font-weight:700;font-size:13px;cursor:pointer;transition:.2s;font-family:inherit}.btn:hover{transform:translateY(-2px)}.btn.primary{background:linear-gradient(135deg,#55575b,#85878b);color:white;box-shadow:0 12px 30px rgba(124,92,255,.25)}.btn.secondary{background:rgba(255,255,255,.06);border:1px solid var(--line)}.btn.full{width:100%}.btn.small{padding:8px 12px;font-size:11px;background:var(--primary);color:#fff}.hero-card{background:linear-gradient(145deg,rgba(20,28,51,.95),rgba(11,17,32,.95));border:1px solid var(--line);border-radius:26px;padding:32px;box-shadow:var(--shadow);position:relative;overflow:hidden}.hero-card:before{content:'';position:absolute;width:180px;height:180px;background:var(--primary);filter:blur(80px);opacity:.25;right:-60px;top:-60px}.hero-card h3{font:600 22px 'Space Grotesk';position:relative}.journey{display:grid;gap:12px;position:relative}.journey div{display:flex;align-items:center;gap:15px;padding:15px;border:1px solid var(--line);border-radius:13px;background:rgba(255,255,255,.035)}.journey b{color:var(--primary2);font-size:11px}.journey span{color:#dce4f2;font-size:13px}.section{max-width:1250px;margin:auto;padding:70px 5%}.section-title h2{font:700 42px 'Space Grotesk';margin:0 0 32px;letter-spacing:-2px}.feature-grid,.quick-grid,.stats-grid,.internship-grid{display:grid;gap:18px}.feature-grid{grid-template-columns:repeat(4,1fr)}.feature-card,.quick-card,.stat-card,.internship-card,.form-card,.detail-card,.table-card{background:rgba(16,23,41,.86);border:1px solid var(--line);border-radius:18px;box-shadow:0 15px 50px rgba(0,0,0,.12)}.feature-card{padding:24px;min-height:205px}.feature-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:rgba(124,92,255,.12);color:#a991ff;font-size:11px;font-weight:800;margin-bottom:28px}.feature-card h3{margin:0 0 10px}.feature-card p,.quick-card p{color:var(--muted);line-height:1.65;font-size:13px}footer{text-align:center;padding:40px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}
.auth-page{display:grid;place-items:center;padding:50px 20px}.auth-container{width:min(1050px,100%);display:grid;grid-template-columns:1fr 1fr;gap:55px;align-items:center}.auth-brand h1{font:700 54px 'Space Grotesk';letter-spacing:-3px;margin:20px 0 14px}.auth-brand p{color:var(--muted);line-height:1.8}.auth-card{background:rgba(16,23,41,.94);border:1px solid var(--line);border-radius:22px;padding:34px;box-shadow:var(--shadow)}.auth-card h2{font:700 30px 'Space Grotesk';margin:0 0 8px}.muted{color:var(--muted);margin:0 0 25px;font-size:13px}label{display:block;font-size:12px;font-weight:700;margin:17px 0 8px;color:#dbe3f0}input,textarea,select{width:100%;border:1px solid var(--line);background:#191a1c;color:var(--text);border-radius:10px;padding:13px 14px;outline:0;font:inherit;font-size:13px}input:focus,textarea:focus,select:focus{border-color:rgba(210,210,210,.75);box-shadow:0 0 0 3px rgba(210,210,210,.1)}textarea{resize:vertical}.auth-card .btn{margin-top:20px}.auth-bottom{text-align:center;color:var(--muted);font-size:13px;margin:22px 0 0}.auth-bottom a{color:var(--primary2)}.alert{padding:13px 15px;border-radius:11px;margin:15px 0;font-size:13px;border:1px solid}.alert.error{background:rgba(255,107,129,.08);color:#ff9aaa;border-color:rgba(255,107,129,.2)}.alert.success{background:rgba(49,211,155,.08);color:#70e8bb;border-color:rgba(49,211,155,.2)}
.dashboard{max-width:1250px;margin:auto;padding:55px 5%}.dashboard.narrow{max-width:950px}.page-heading{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:32px}.page-heading h1{font:700 44px 'Space Grotesk';letter-spacing:-2px;margin:0 0 7px}.page-heading p:not(.eyebrow){color:var(--muted);margin:0}.stats-grid{grid-template-columns:repeat(3,1fr);margin-bottom:25px}.stat-card{padding:24px}.stat-card span{color:var(--muted);font-size:12px}.stat-card strong{display:block;font:700 38px 'Space Grotesk';margin-top:10px}.quick-grid{grid-template-columns:repeat(3,1fr)}.quick-card{padding:25px;transition:.2s}.quick-card:hover{transform:translateY(-3px);border-color:rgba(124,92,255,.5)}.quick-card h3{margin:0 0 9px}.form-card,.detail-card{padding:30px}.form-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:0 20px}.small-text{color:var(--muted);font-size:12px;margin-top:8px}.search-bar{display:grid;grid-template-columns:1.4fr .8fr auto;gap:10px;margin-bottom:25px}.internship-grid{grid-template-columns:repeat(2,1fr)}.internship-card{padding:24px}.internship-card h2{font:600 24px 'Space Grotesk';margin:14px 0 7px}.internship-card h4{color:var(--primary2);margin:0 0 15px;font-size:13px}.internship-card p{color:var(--muted);line-height:1.7;margin:0 0 17px}.tags{display:flex;flex-wrap:wrap;gap:7px;margin-bottom:20px}.tags span{background:rgba(255,255,255,.045);padding:7px 10px;border-radius:7px;color:#bcc8da;font-size:11px}.status{display:inline-block;padding:6px 10px;border-radius:999px;background:rgba(124,92,255,.12);color:#b6a4ff;font-size:10px;font-weight:800}.status.open,.status.selected{background:rgba(49,211,155,.12);color:#62e5b4}.status.rejected{background:rgba(255,107,129,.12);color:#ff91a2}.status.interview,.status.shortlisted{background:rgba(245,185,66,.12);color:#ffd477}.detail-card h1{font:700 44px 'Space Grotesk';letter-spacing:-2px;margin:18px 0 8px}.detail-card h3{color:var(--primary2);margin-bottom:25px}.detail-card>p{color:var(--muted);line-height:1.8}.detail-info{margin:25px 0;padding:20px;background:rgba(255,255,255,.035);border-radius:12px}.detail-info p{color:var(--muted);margin:9px 0}.table-card{overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:760px}th,td{text-align:left;padding:16px;border-bottom:1px solid var(--line);font-size:12px}th{color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:1px}td{color:#dce5f1}.inline-form{display:flex;gap:7px}.inline-form select{width:145px;padding:8px}.empty{text-align:center;padding:45px;color:var(--muted)}.notice{padding:12px 15px;border-radius:10px;background:rgba(34,211,238,.07);border:1px solid rgba(34,211,238,.14);color:#9debf5;font-size:13px;margin-bottom:20px}
@media(max-width:900px){.hero,.auth-container{grid-template-columns:1fr}.feature-grid{grid-template-columns:1fr 1fr}.hero{padding-top:65px}.stats-grid,.quick-grid{grid-template-columns:1fr 1fr}.internship-grid{grid-template-columns:1fr}}@media(max-width:600px){.navbar{height:auto;padding:16px 20px;align-items:flex-start;gap:13px;flex-direction:column}.nav-links{gap:12px;flex-wrap:wrap}.hero{padding:55px 20px}.hero h1{font-size:46px}.feature-grid,.stats-grid,.quick-grid,.form-grid,.search-bar{grid-template-columns:1fr}.page-heading{align-items:flex-start;flex-direction:column}.page-heading h1{font-size:35px}.dashboard,.section{padding-left:20px;padding-right:20px}.auth-brand h1{font-size:43px}}

apply.app
<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
if (($_SESSION['role'] ?? '') !== 'student') { header('Location: ../login.php'); exit; }
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

$internshipId = (int)($_GET['internship_id'] ?? $_POST['internship_id'] ?? 0);
$internship = null;
$error = '';
$success = '';

try {
    if (!isset($pdo) || !($pdo instanceof PDO)) throw new RuntimeException('PDO connection missing.');
    $q = $pdo->prepare("SELECT * FROM internships WHERE id=:id AND status='Open' LIMIT 1");
    $q->execute(['id' => $internshipId]);
    $internship = $q->fetch(PDO::FETCH_ASSOC) ?: null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $internship) {
        $sq = $pdo->prepare('SELECT id FROM students WHERE user_id=:uid LIMIT 1');
        $sq->execute(['uid' => (int)$_SESSION['user_id']]);
        $studentId = (int)$sq->fetchColumn();
        if (!$studentId) {
            $error = 'Please create your student profile before applying.';
        } else {
            $check = $pdo->prepare('SELECT id FROM applications WHERE student_id=:sid AND internship_id=:iid LIMIT 1');
            $check->execute(['sid' => $studentId, 'iid' => $internshipId]);
            if ($check->fetchColumn()) {
                $success = 'You have already applied for this internship.';
            } else {
                $insert = $pdo->prepare("INSERT INTO applications (student_id, internship_id, status) VALUES (:sid, :iid, 'Applied')");
                $insert->execute(['sid' => $studentId, 'iid' => $internshipId]);
                $success = 'Your application has been submitted successfully.';
            }
        }
    }
} catch (Throwable $ex) {
    error_log('InternTrack apply: '.$ex->getMessage());
    $error = 'Application could not be submitted. Confirm that applications has student_id, internship_id, and status columns.';
}
require __DIR__ . '/student_nav.php';
?>
<link rel="stylesheet" href="../css/student.css">
<main class="it-page">
    <section class="it-page-head">
        <div><p class="it-eyebrow">Take the next step</p><h1>Apply for an <span class="it-gradient">Internship</span></h1>
        <p class="it-muted">Review the opportunity before submitting your application.</p></div>
    </section>
    <?php if ($success): ?>
        <div class="it-alert success"><?= e($success) ?></div>
        <a class="it-button" href="applications.php">View my applications →</a>
    <?php elseif ($error): ?>
        <div class="it-alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($internship): ?>
        <?php $title = $internship['title'] ?? $internship['role'] ?? 'Internship opportunity'; ?>
        <article class="it-item">
            <span class="it-pill">Open opportunity</span>
            <h2 style="margin:14px 0 8px"><?= e($title) ?></h2>
            <p class="it-muted"><?= e($internship['description'] ?? 'No description provided.') ?></p>
            <div class="it-meta">
                <span>⌖ <?= e($internship['location'] ?? 'Location not specified') ?></span>
                <?php if (!empty($internship['stipend'])): ?><span>◈ Stipend: <?= e($internship['stipend']) ?></span><?php endif; ?>
                <?php if (!empty($internship['duration'])): ?><span>◷ <?= e($internship['duration']) ?></span><?php endif; ?>
            </div>
            <?php if (!$success): ?>
                <form method="post" action="apply.php" style="margin-top:22px">
                    <input type="hidden" name="internship_id" value="<?= $internshipId ?>">
                    <button class="it-button" type="submit">Submit application →</button>
                    <a class="it-button secondary" href="internships.php">Back to internships</a>
                </form>
            <?php endif; ?>
        </article>
    <?php elseif (!$error): ?>
        <div class="it-empty">This internship is not available or could not be found. <a href="internships.php" style="color:var(--it-cyan)">Browse open internships →</a></div>
    <?php endif; ?>
    <footer class="it-footer">✦ InternTrack · Good luck with your application.</footer>
</main>
