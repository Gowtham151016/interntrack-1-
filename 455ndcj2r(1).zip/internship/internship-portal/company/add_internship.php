<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_role('company');

$error = '';
$title = '';
$description = '';
$location = '';
$skills = '';
$duration = '';
$stipend = '';
$companyId = 0;

if (!$pdo instanceof PDO) {
    $error = $dbError ?: 'Database connection is unavailable.';
} else {
    try {
        $stmt = $pdo->prepare('SELECT id FROM companies WHERE user_id = :uid LIMIT 1');
        $stmt->execute(['uid' => (int)$_SESSION['user_id']]);
        $companyId = (int)$stmt->fetchColumn();
        if ($companyId < 1) {
            $error = 'A company profile was not found for this account.';
        }
    } catch (Throwable $exception) {
        error_log('InternTrack company profile lookup: ' . $exception->getMessage());
        $error = 'Could not load your company profile. Check the database connection.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    $title = trim((string)($_POST['title'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $location = trim((string)($_POST['location'] ?? ''));
    $skills = trim((string)($_POST['skills'] ?? ''));
    $duration = trim((string)($_POST['duration'] ?? ''));
    $stipend = trim((string)($_POST['stipend'] ?? ''));

    if ($title === '' || $description === '' || $location === '') {
        $error = 'Please complete the title, description and location.';
    } elseif (strlen($title) > 150 || strlen($location) > 100 || strlen($skills) > 255 || strlen($duration) > 100 || strlen($stipend) > 100) {
        $error = 'One or more fields exceed the allowed length. Shorten the title, location, skills, duration or stipend.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO internships (company_id, title, description, location, skills, duration, stipend, status) VALUES (:cid, :title, :description, :location, :skills, :duration, :stipend, 'Open')");
            $stmt->execute([
                'cid' => $companyId,
                'title' => $title,
                'description' => $description,
                'location' => $location,
                'skills' => $skills !== '' ? $skills : null,
                'duration' => $duration !== '' ? $duration : null,
                'stipend' => $stipend !== '' ? $stipend : null,
            ]);
            flash('success', 'Internship published successfully.');
            header('Location: internships.php');
            exit;
        } catch (Throwable $exception) {
            error_log('InternTrack add internship: ' . $exception->getMessage());
            $error = 'Unable to publish the internship. Please check the internships table and try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Post Internship · InternTrack</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/../includes/galaxy_bg.php'; include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard narrow">
    <div class="page-heading"><div><p class="eyebrow">NEW OPPORTUNITY</p><h1>Post an internship.</h1><p>Give students the information they need to apply confidently.</p></div></div>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <div class="form-card">
        <form method="post" action="add_internship.php">
            <label for="title">Internship title *</label>
            <input id="title" name="title" maxlength="150" value="<?= e($title) ?>" placeholder="e.g. Full Stack Developer Intern" required>
            <label for="description">Description *</label>
            <textarea id="description" name="description" rows="7" placeholder="Responsibilities, requirements and what the intern will learn..." required><?= e($description) ?></textarea>
            <div class="form-grid">
                <div><label for="location">Location *</label><input id="location" name="location" maxlength="100" value="<?= e($location) ?>" placeholder="Chennai / Remote" required></div>
                <div><label for="skills">Skills</label><input id="skills" name="skills" maxlength="255" value="<?= e($skills) ?>" placeholder="PHP, MySQL, JavaScript"></div>
                <div><label for="duration">Duration</label><input id="duration" name="duration" maxlength="100" value="<?= e($duration) ?>" placeholder="3 months"></div>
                <div><label for="stipend">Stipend</label><input id="stipend" name="stipend" maxlength="100" value="<?= e($stipend) ?>" placeholder="₹10,000 / month"></div>
            </div>
            <button class="btn primary" type="submit" <?= $companyId < 1 ? 'disabled' : '' ?>>Publish internship</button>
        </form>
    </div>
</main>
</body>
</html>
