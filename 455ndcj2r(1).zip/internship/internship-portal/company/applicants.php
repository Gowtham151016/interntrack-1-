<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_role('company');

$allowed = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];
$rows = [];
$error = '';
$message = '';
$companyId = 0;

if (!$pdo instanceof PDO) {
    $error = $dbError ?: 'Database connection is unavailable.';
} else {
    try {
        $stmt = $pdo->prepare('SELECT id FROM companies WHERE user_id = :uid LIMIT 1');
        $stmt->execute(['uid' => (int)$_SESSION['user_id']]);
        $companyId = (int)$stmt->fetchColumn();

        if ($companyId < 1) {
            $error = 'A company profile was not found for this account.';
        } else {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $applicationId = (int)($_POST['application_id'] ?? 0);
                $newStatus = (string)($_POST['status'] ?? '');
                if (!in_array($newStatus, $allowed, true)) {
                    $message = 'Please choose a valid application status.';
                } else {
                    $check = $pdo->prepare('SELECT a.id FROM applications a INNER JOIN internships i ON i.id = a.internship_id WHERE a.id = :aid AND i.company_id = :cid LIMIT 1');
                    $check->execute(['aid' => $applicationId, 'cid' => $companyId]);
                    if ($check->fetchColumn()) {
                        $update = $pdo->prepare('UPDATE applications SET status = :status WHERE id = :aid');
                        $update->execute(['status' => $newStatus, 'aid' => $applicationId]);
                        $message = 'Application status updated.';
                    } else {
                        $message = 'That application does not belong to your company.';
                    }
                }
            }

            $stmt = $pdo->prepare('SELECT a.id, a.status, a.applied_at, u.name AS student_name, u.email, s.skills, s.college, i.title FROM applications a INNER JOIN internships i ON i.id = a.internship_id INNER JOIN students s ON s.id = a.student_id INNER JOIN users u ON u.id = s.user_id WHERE i.company_id = :cid ORDER BY a.applied_at DESC, a.id DESC');
            $stmt->execute(['cid' => $companyId]);
            $rows = $stmt->fetchAll();
        }
    } catch (Throwable $exception) {
        error_log('InternTrack company applicants: ' . $exception->getMessage());
        $error = 'Applicants could not be loaded or updated. Check the database connection and schema.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Applicants · InternTrack</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/../includes/galaxy_bg.php'; include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard">
    <div class="page-heading"><div><p class="eyebrow">CANDIDATE PIPELINE</p><h1>Applicants.</h1><p>Review candidates and keep their application status current.</p></div></div>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($message): ?><div class="alert <?= $message === 'Application status updated.' ? 'success' : 'error' ?>"><?= e($message) ?></div><?php endif; ?>
    <div class="table-card"><table><thead><tr><th>Student</th><th>Internship</th><th>Skills</th><th>Applied</th><th>Status</th><th>Update</th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="6" class="empty">No applicants yet.</td></tr><?php else: foreach ($rows as $row): ?>
        <tr><td><strong><?= e($row['student_name']) ?></strong><br><small><?= e($row['email']) ?></small></td><td><?= e($row['title']) ?></td><td><?= e($row['skills'] ?: 'Not added') ?></td><td><?= !empty($row['applied_at']) ? e(date('d M Y', strtotime($row['applied_at']))) : '—' ?></td><td><span class="status <?= e(status_class((string)$row['status'])) ?>"><?= e($row['status']) ?></span></td><td><form method="post" class="inline-form"><input type="hidden" name="application_id" value="<?= (int)$row['id'] ?>"><select name="status" aria-label="Application status"><?php foreach ($allowed as $status): ?><option value="<?= e($status) ?>" <?= $row['status'] === $status ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?></select><button class="btn small" type="submit">Save</button></form></td></tr>
    <?php endforeach; endif; ?>
    </tbody></table></div>
</main>
</body>
</html>
