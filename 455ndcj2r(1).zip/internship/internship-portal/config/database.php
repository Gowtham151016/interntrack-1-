<?php
$host = "db01.dbhost.dev";
$dbname = "db_455a2gvcw";
$username = "user_455a2gvcw";
$password = "p455a2gvcw";
$port = 5051;

try {
    $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";

    $pdo = new PDO(
        $dsn,
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 10
        ]
    );

} catch (PDOException $e) {
    http_response_code(500);

    // Log the complete error in the PHP server terminal.
    error_log("InternTrack DB ERROR: " . $e->getMessage());

    // Display the exact error temporarily for debugging.
    echo "<h2>Database Connection Failed</h2>";
    echo "<p><strong>Host:</strong> " .
         htmlspecialchars($host, ENT_QUOTES, 'UTF-8') . "</p>";
    echo "<p><strong>Database:</strong> " .
         htmlspecialchars($dbname, ENT_QUOTES, 'UTF-8') . "</p>";
    echo "<p><strong>Username:</strong> " .
         htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . "</p>";
    echo "<p><strong>Error:</strong> " .
         htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "</p>";

    exit;
}
