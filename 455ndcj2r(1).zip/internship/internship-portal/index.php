
<?php
session_start();

$loggedIn = isset($_SESSION["user_id"]);
$role = $_SESSION["role"] ?? "";

$dashboard = match ($role) {
    "student" => "student/dashboard.php",
    "company" => "company/dashboard.php",
    "admin"   => "admin/dashboard.php",
    default   => "login.php"
};

$dashboard = htmlspecialchars($dashboard, ENT_QUOTES, "UTF-8");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternTrack | Your Career Starts Here</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #070910;
            --surface: #101522;
            --surface-light: #151d2d;
            --blue: #4f8cff;
            --cyan: #53f3e4;
            --purple: #a78bfa;
            --white: #f5f7ff;
            --muted: #929bb2;
            --border: rgba(255,255,255,0.09);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: 95px;
        }

        body {
            font-family: "Inter", sans-serif;
            background: var(--bg);
            color: var(--white);
            overflow-x: hidden;
        }

        body::selection {
            background: var(--cyan);
            color: #070910;
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        button,
        a {
            -webkit-tap-highlight-color: transparent;
        }

        /* BACKGROUND EFFECTS */

        .ambient {
            position: fixed;
            width: 420px;
            height: 420px;
            border-radius: 50%;
            filter: blur(130px);
            opacity: 0.14;
            z-index: -3;
            pointer-events: none;
            animation: ambientMove 15s ease-in-out infinite alternate;
        }

        .ambient-one {
            background: #255cff;
            top: -200px;
            left: -150px;
        }

        .ambient-two {
            background: #8b5cf6;
            top: 35%;
            right: -230px;
            animation-delay: -7s;
        }

        .ambient-three {
            background: #00d9c6;
            bottom: -250px;
            left: 25%;
            animation-delay: -4s;
        }

        @keyframes ambientMove {
            0% {
                transform: translate(0, 0) scale(1);
            }
            50% {
                transform: translate(70px, 40px) scale(1.15);
            }
            100% {
                transform: translate(-30px, 80px) scale(0.9);
            }
        }

        .grid-background {
            position: fixed;
            inset: 0;
            z-index: -2;
            pointer-events: none;
            opacity: 0.22;
            background-image:
                linear-gradient(rgba(112,145,210,0.07) 1px, transparent 1px),
                linear-gradient(90deg, rgba(112,145,210,0.07) 1px, transparent 1px);
            background-size: 55px 55px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
            animation: gridMove 25s linear infinite;
        }

        @keyframes gridMove {
            from {
                background-position: 0 0;
            }
            to {
                background-position: 55px 55px;
            }
        }

        /* NAVIGATION */

        .navbar {
            height: 82px;
            padding: 0 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(7,9,16,0.84);
            border-bottom: 1px solid rgba(255,255,255,0.07);
            backdrop-filter: blur(22px);
        }

        /* New custom IT logo */

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }

        .brand-symbol {
            width: 45px;
            height: 45px;
            position: relative;
            display: grid;
            place-items: center;
            border-radius: 14px;
            background: #0d1422;
            isolation: isolate;
        }

        .brand-symbol::before {
            content: "";
            position: absolute;
            inset: -1.5px;
            border-radius: 15px;
            background: conic-gradient(
                from var(--rotation, 0deg),
                var(--blue),
                var(--cyan),
                var(--purple),
                var(--blue)
            );
            animation: logoRotate 4s linear infinite;
            z-index: -2;
        }

        .brand-symbol::after {
            content: "";
            position: absolute;
            inset: 1px;
            border-radius: 13px;
            background: #0d1422;
            z-index: -1;
        }

        @property --rotation {
            syntax: "<angle>";
            initial-value: 0deg;
            inherits: false;
        }

        @keyframes logoRotate {
            to {
                --rotation: 360deg;
            }
        }

        .brand-symbol svg {
            width: 27px;
            height: 27px;
            filter: drop-shadow(0 0 8px rgba(83,243,228,0.4));
        }

        .brand-name {
            font-size: 23px;
            font-weight: 900;
            letter-spacing: -1px;
        }

        .brand-name span {
            color: var(--cyan);
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-links > a:not(.nav-cta) {
            font-size: 13px;
            font-weight: 500;
            color: var(--muted);
            transition: color 0.3s;
        }

        .nav-links > a:not(.nav-cta):hover {
            color: var(--cyan);
        }

        .nav-cta {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 12px 19px;
            border-radius: 10px;
            background: linear-gradient(110deg, #376fff, #7657ef);
            color: white;
            font-size: 13px;
            font-weight: 700;
            box-shadow: 0 0 25px rgba(79,140,255,0.15);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .nav-cta:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(79,140,255,0.35);
        }

        /* HERO */

        .hero {
            min-height: 700px;
            padding: 90px 7% 85px;
            display: grid;
            grid-template-columns: 1.05fr 0.95fr;
            align-items: center;
            gap: 50px;
        }

        .hero-copy {
            animation: heroEnter 1s cubic-bezier(.2,.8,.2,1) both;
        }

        @keyframes heroEnter {
            from {
                opacity: 0;
                transform: translateY(35px);
                filter: blur(5px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
                filter: blur(0);
            }
        }

        .announcement {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            margin-bottom: 29px;
            border: 1px solid rgba(83,243,228,0.2);
            border-radius: 50px;
            background: rgba(83,243,228,0.045);
            color: #a6fff5;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .announcement-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--cyan);
            box-shadow: 0 0 12px var(--cyan);
            animation: dotPulse 1.6s ease infinite;
        }

        @keyframes dotPulse {
            50% {
                opacity: 0.35;
                transform: scale(0.65);
            }
        }

        .hero h1 {
            font-size: clamp(43px, 5.4vw, 76px);
            font-weight: 900;
            line-height: 1.06;
            letter-spacing: -4px;
            margin-bottom: 27px;
        }

        .hero h1 .line {
            display: block;
        }

        .gradient-text {
            color: transparent;
            background: linear-gradient(
                100deg,
                #53f3e4 0%,
                #4f8cff 35%,
                #b59bff 65%,
                #53f3e4 100%
            );
            background-size: 250% auto;
            -webkit-background-clip: text;
            background-clip: text;
            animation: textFlow 5s linear infinite;
        }

        @keyframes textFlow {
            to {
                background-position: 250% center;
            }
        }

        .hero-description {
            max-width: 525px;
            font-size: 15px;
            line-height: 1.95;
            color: var(--muted);
            margin-bottom: 31px;
        }

        .hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
            margin-bottom: 35px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 11px;
            min-height: 51px;
            padding: 14px 22px;
            border-radius: 11px;
            font-size: 13px;
            font-weight: 700;
            transition: transform 0.3s, border-color 0.3s, box-shadow 0.3s;
        }

        .btn-primary {
            color: #fff;
            background: linear-gradient(110deg, #376fff, #7957f1);
            box-shadow: 0 8px 30px rgba(55,111,255,0.2);
        }

        .btn-primary:hover {
            transform: translateY(-4px);
            box-shadow: 0 13px 35px rgba(55,111,255,0.36);
        }

        .btn-secondary {
            border: 1px solid rgba(255,255,255,0.14);
            background: rgba(255,255,255,0.025);
            color: var(--white);
        }

        .btn-secondary:hover {
            transform: translateY(-4px);
            border-color: var(--cyan);
            color: var(--cyan);
        }

        .hero-footnote {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #8c97af;
            font-size: 11px;
        }

        .footnote-line {
            width: 32px;
            height: 1px;
            background: var(--cyan);
        }

        /* ANIMATED DASHBOARD ILLUSTRATION */

        .hero-art {
            min-height: 480px;
            display: grid;
            place-items: center;
            position: relative;
            perspective: 1000px;
            animation: heroEnter 1.1s 0.15s both;
        }

        .art-glow {
            position: absolute;
            width: 280px;
            height: 280px;
            border-radius: 50%;
            background: rgba(56,107,255,0.18);
            filter: blur(75px);
            animation: glowBreath 4s ease-in-out infinite;
        }

        @keyframes glowBreath {
            50% {
                transform: scale(1.3);
                opacity: 0.6;
            }
        }

        .ring {
            position: absolute;
            width: 390px;
            height: 390px;
            border-radius: 50%;
            border: 1px solid rgba(79,140,255,0.2);
            animation: ringSpin 22s linear infinite;
        }

        .ring::before,
        .ring::after {
            content: "";
            position: absolute;
            width: 11px;
            height: 11px;
            border-radius: 50%;
        }

        .ring::before {
            top: 45px;
            left: 45px;
            background: var(--cyan);
            box-shadow: 0 0 18px var(--cyan);
        }

        .ring::after {
            bottom: 35px;
            right: 55px;
            background: var(--purple);
            box-shadow: 0 0 18px var(--purple);
        }

        .ring-two {
            width: 315px;
            height: 315px;
            border-style: dashed;
            border-color: rgba(167,139,250,0.23);
            animation-direction: reverse;
            animation-duration: 35s;
        }

        @keyframes ringSpin {
            to {
                transform: rotate(360deg);
            }
        }

        .dashboard-card {
            position: relative;
            z-index: 2;
            width: min(365px, 82%);
            padding: 25px;
            border: 1px solid rgba(255,255,255,0.13);
            border-radius: 23px;
            background: linear-gradient(
                145deg,
                rgba(22,31,51,0.97),
                rgba(11,16,29,0.97)
            );
            box-shadow:
                0 30px 90px rgba(0,0,0,0.45),
                inset 0 1px 0 rgba(255,255,255,0.04);
            animation: dashboardFloat 5s ease-in-out infinite;
            transform-style: preserve-3d;
        }

        @keyframes dashboardFloat {
            0%, 100% {
                transform: translateY(0) rotateX(1deg) rotateY(-2deg);
            }
            50% {
                transform: translateY(-13px) rotateX(-1deg) rotateY(2deg);
            }
        }

        .dashboard-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
        }

        .dashboard-head small {
            font-size: 10px;
            letter-spacing: 1.5px;
            color: var(--muted);
            font-weight: 700;
        }

        .live-badge {
            font-size: 10px;
            color: #78f5bd;
            padding: 7px 10px;
            border-radius: 20px;
            background: rgba(72,230,159,0.09);
            border: 1px solid rgba(72,230,159,0.15);
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 13px;
            margin-bottom: 25px;
        }

        .avatar {
            width: 55px;
            height: 55px;
            display: grid;
            place-items: center;
            border-radius: 17px;
            font-size: 25px;
            background: linear-gradient(135deg, #356dff, #9c64f8);
            box-shadow: 0 5px 22px rgba(79,140,255,0.2);
        }

        .profile h3 {
            font-size: 15px;
            margin-bottom: 6px;
        }

        .profile p {
            color: var(--muted);
            font-size: 11px;
        }

        .separator {
            height: 1px;
            background: rgba(255,255,255,0.08);
            margin-bottom: 22px;
        }

        .progress-info {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            margin-bottom: 11px;
        }

        .progress-info span:first-child {
            color: var(--muted);
        }

        .progress-info span:last-child {
            color: var(--cyan);
            font-weight: 700;
        }

        .progress-bar {
            height: 7px;
            border-radius: 20px;
            overflow: hidden;
            background: #273047;
            margin-bottom: 24px;
        }

        .progress-bar span {
            display: block;
            height: 100%;
            width: 0;
            border-radius: inherit;
            background: linear-gradient(90deg, #4277ff, #53f3e4);
            animation: progressGrow 2s 0.5s ease forwards;
        }

        @keyframes progressGrow {
            to {
                width: 78%;
            }
        }

        .skills-heading {
            font-size: 11px;
            color: var(--muted);
            margin-bottom: 12px;
        }

        .skills {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .skills span {
            padding: 8px 10px;
            border-radius: 7px;
            background: rgba(79,140,255,0.1);
            border: 1px solid rgba(79,140,255,0.12);
            color: #a7c2ff;
            font-size: 10px;
        }

        .float-box {
            position: absolute;
            z-index: 3;
            padding: 15px 17px;
            border-radius: 13px;
            background: rgba(19,27,45,0.97);
            border: 1px solid rgba(255,255,255,0.12);
            box-shadow: 0 16px 40px rgba(0,0,0,0.3);
            animation: floatBox 4s ease-in-out infinite;
        }

        .float-box strong {
            display: block;
            font-size: 12px;
            margin-bottom: 6px;
        }

        .float-box small {
            display: block;
            color: var(--muted);
            font-size: 10px;
        }

        .float-box-top {
            top: 38px;
            right: -3px;
        }

        .float-box-bottom {
            bottom: 35px;
            left: -3px;
            animation-delay: -2s;
        }

        @keyframes floatBox {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-12px);
            }
        }

        /* SECTION SHARED STYLES */

        .section {
            padding: 95px 7%;
        }

        .section-heading {
            text-align: center;
            max-width: 660px;
            margin: 0 auto 52px;
        }

        .section-tag {
            display: inline-block;
            color: var(--cyan);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 2px;
            margin-bottom: 17px;
        }

        .section-heading h2 {
            font-size: clamp(29px, 4vw, 44px);
            line-height: 1.2;
            letter-spacing: -1.8px;
            margin-bottom: 17px;
        }

        .section-heading p {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.9;
        }

        /* FEATURE CARDS */

        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 19px;
        }

        .feature-card {
            position: relative;
            overflow: hidden;
            padding: 29px;
            border: 1px solid var(--border);
            border-radius: 18px;
            background: linear-gradient(145deg, #111827, #0b101b);
            transition: transform 0.35s, border-color 0.35s, box-shadow 0.35s;
        }

        .feature-card::before {
            content: "";
            position: absolute;
            width: 150px;
            height: 150px;
            top: -100px;
            right: -100px;
            background: var(--blue);
            filter: blur(70px);
            opacity: 0;
            transition: opacity 0.35s;
        }

        .feature-card:hover {
            transform: translateY(-9px);
            border-color: rgba(83,243,228,0.3);
            box-shadow: 0 20px 55px rgba(0,0,0,0.18);
        }

        .feature-card:hover::before {
            opacity: 0.22;
        }

        .feature-icon {
            width: 52px;
            height: 52px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(79,140,255,0.18);
            border-radius: 15px;
            background: rgba(79,140,255,0.09);
            font-size: 23px;
            margin-bottom: 24px;
            transition: transform 0.4s;
        }

        .feature-card:hover .feature-icon {
            transform: rotate(-8deg) scale(1.08);
        }

        .feature-card h3 {
            font-size: 16px;
            margin-bottom: 12px;
        }

        .feature-card p {
            color: var(--muted);
            font-size: 12px;
            line-height: 1.95;
        }

        /* HOW IT WORKS */

        .steps-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .step-card {
            padding: 30px;
            border-radius: 17px;
            border: 1px solid var(--border);
            background: rgba(16,21,34,0.8);
            transition: transform 0.35s, border-color 0.35s;
        }

        .step-card:hover {
            transform: translateY(-7px);
            border-color: rgba(167,139,250,0.4);
        }

        .step-number {
            display: inline-flex;
            width: 45px;
            height: 45px;
            align-items: center;
            justify-content: center;
            border-radius: 13px;
            margin-bottom: 22px;
            font-size: 13px;
            font-weight: 900;
            color: var(--cyan);
            background: rgba(83,243,228,0.07);
            border: 1px solid rgba(83,243,228,0.15);
        }

        .step-card h3 {
            font-size: 16px;
            margin-bottom: 12px;
        }

        .step-card p {
            color: var(--muted);
            font-size: 12px;
            line-height: 1.95;
        }

        /* CALL TO ACTION */

        .cta-section {
            padding: 30px 7% 100px;
        }

        .cta-box {
            max-width: 1100px;
            margin: 0 auto;
            position: relative;
            overflow: hidden;
            padding: 70px 25px;
            text-align: center;
            border: 1px solid rgba(79,140,255,0.23);
            border-radius: 25px;
            background:
                radial-gradient(ellipse at top left, rgba(55,111,255,0.16), transparent 50%),
                radial-gradient(ellipse at bottom right, rgba(83,243,228,0.09), transparent 50%),
                #101522;
        }

        .cta-box::after {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 50%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), transparent);
            animation: lightSweep 5s linear infinite;
        }

        @keyframes lightSweep {
            to {
                left: 150%;
            }
        }

        .cta-box h2 {
            font-size: clamp(29px, 4vw, 45px);
            letter-spacing: -1.5px;
            margin-bottom: 18px;
        }

        .cta-box p {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.9;
            margin-bottom: 28px;
        }

        /* FOOTER */

        .footer {
            min-height: 100px;
            padding: 25px 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            border-top: 1px solid rgba(255,255,255,0.07);
        }

        .footer-brand {
            font-size: 14px;
            font-weight: 800;
        }

        .footer-brand span {
            color: var(--cyan);
        }

        .footer p {
            font-size: 11px;
            color: #7f8ba4;
        }

        /* SCROLL REVEAL */

        .reveal {
            opacity: 0;
            transform: translateY(35px);
            transition:
                opacity 0.75s ease,
                transform 0.75s cubic-bezier(.2,.7,.2,1);
        }

        .reveal.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .features-grid .feature-card:nth-child(2),
        .steps-grid .step-card:nth-child(2) {
            transition-delay: 0.1s;
        }

        .features-grid .feature-card:nth-child(3),
        .steps-grid .step-card:nth-child(3) {
            transition-delay: 0.2s;
        }

        /* TABLET */

        @media (max-width: 1000px) {
            .navbar {
                padding: 0 5%;
            }

            .nav-links {
                gap: 17px;
            }

            .hero {
                padding-left: 5%;
                padding-right: 5%;
                grid-template-columns: 1fr 0.9fr;
                gap: 20px;
            }

            .hero h1 {
                font-size: clamp(42px, 5.5vw, 62px);
                letter-spacing: -3px;
            }

            .ring {
                width: 320px;
                height: 320px;
            }

            .ring-two {
                width: 260px;
                height: 260px;
            }

            .features-grid,
            .steps-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        /* MOBILE */

        @media (max-width: 700px) {
            .navbar {
                height: auto;
                min-height: 76px;
                padding: 14px 5%;
                flex-wrap: wrap;
                gap: 14px;
            }

            .brand-symbol {
                width: 39px;
                height: 39px;
            }

            .brand-name {
                font-size: 21px;
            }

            .nav-links {
                width: 100%;
                justify-content: space-between;
                gap: 10px;
                flex-wrap: wrap;
            }

            .nav-links > a:not(.nav-cta) {
                font-size: 11px;
            }

            .nav-cta {
                padding: 10px 12px;
                font-size: 11px;
            }

            .hero {
                grid-template-columns: 1fr;
                padding: 65px 6% 55px;
                gap: 35px;
            }

            .hero-copy {
                text-align: center;
            }

            .announcement {
                font-size: 9px;
                letter-spacing: 0.6px;
            }

            .hero h1 {
                font-size: clamp(42px, 10vw, 62px);
                letter-spacing: -2.8px;
            }

            .hero-description {
                font-size: 13px;
                margin-left: auto;
                margin-right: auto;
            }

            .hero-actions {
                justify-content: center;
            }

            .hero-footnote {
                justify-content: center;
                font-size: 10px;
            }

            .hero-art {
                min-height: 390px;
                width: 100%;
                overflow: hidden;
            }

            .ring {
                width: 290px;
                height: 290px;
            }

            .ring-two {
                width: 230px;
                height: 230px;
            }

            .dashboard-card {
                width: min(340px, 82%);
                padding: 21px;
            }

            .float-box-top {
                top: 12px;
                right: 0;
            }

            .float-box-bottom {
                bottom: 8px;
                left: 0;
            }

            .section {
                padding: 70px 6%;
            }

            .section-heading {
                margin-bottom: 35px;
            }

            .features-grid,
            .steps-grid {
                grid-template-columns: 1fr;
            }

            .feature-card,
            .step-card {
                padding: 25px;
            }

            .cta-section {
                padding: 15px 6% 65px;
            }

            .cta-box {
                padding: 50px 20px;
            }

            .footer {
                flex-direction: column;
                justify-content: center;
                text-align: center;
                padding: 28px 6%;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
                transition-duration: 0.01ms !important;
            }

            .reveal {
                opacity: 1;
                transform: none;
            }
        }
    </style>
    <link rel="stylesheet" href="css/galaxy.css">
</head>

<body>
<?php include __DIR__ . '/includes/galaxy_bg.php'; ?>

    <div class="ambient ambient-one"></div>
    <div class="ambient ambient-two"></div>
    <div class="ambient ambient-three"></div>
    <div class="grid-background"></div>

    <!-- NAVIGATION -->
    <header class="navbar">

        <a href="index.php" class="brand" aria-label="InternTrack home">

            <div class="brand-symbol">
                <svg viewBox="0 0 32 32" fill="none" aria-hidden="true">
                    <path d="M8 7V25" stroke="#53f3e4" stroke-width="3.2" stroke-linecap="round"/>
                    <path d="M5 7H14" stroke="#53f3e4" stroke-width="3.2" stroke-linecap="round"/>
                    <path d="M5 16H12" stroke="#53f3e4" stroke-width="3.2" stroke-linecap="round"/>
                    <path d="M17 7H24C27 7 28 9 28 12C28 15 26 16 23 16H17V25" stroke="#8daaff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M17 16L27 25" stroke="#8daaff" stroke-width="3" stroke-linecap="round"/>
                </svg>
            </div>

            <div class="brand-name">Intern<span>Track</span></div>

        </a>

        <nav class="nav-links" aria-label="Main navigation">
            <a href="#home">Home</a>
            <a href="#features">Features</a>
            <a href="#how-it-works">How It Works</a>

            <?php if ($loggedIn): ?>

                <a href="<?= $dashboard ?>">Dashboard</a>
                <a href="logout.php" class="nav-cta">Logout ↗</a>

            <?php else: ?>

                <a href="login.php">Log In</a>
                <a href="register.php" class="nav-cta">Get Started <span>↗</span></a>

            <?php endif; ?>
        </nav>

    </header>

    <main>

        <!-- HERO SECTION -->
        <section class="hero" id="home">

            <div class="hero-copy">

                <div class="announcement">
                    <span class="announcement-dot"></span>
                    YOUR NEXT CHAPTER STARTS HERE
                </div>

                <h1>
                    <span class="line">Discover.</span>
                    <span class="line">Learn.</span>
                    <span class="line gradient-text">Launch Your Career.</span>
                </h1>

                <p class="hero-description">
                    Find internship opportunities, showcase your skills,
                    connect with companies, and take meaningful steps
                    toward your professional future with InternTrack.
                </p>

                <div class="hero-actions">

                    <?php if ($loggedIn): ?>

                        <a href="<?= $dashboard ?>" class="btn btn-primary">
                            Go to Dashboard <span>→</span>
                        </a>

                        <a href="logout.php" class="btn btn-secondary">
                            Logout ↗
                        </a>

                    <?php else: ?>

                        <a href="register.php" class="btn btn-primary">
                            Start Your Journey <span>→</span>
                        </a>

                        <a href="login.php" class="btn btn-secondary">
                            Explore Your Account <span>↗</span>
                        </a>

                    <?php endif; ?>

                </div>

                <div class="hero-footnote">
                    <span class="footnote-line"></span>
                    <span>One platform. New possibilities.</span>
                </div>

            </div>

            <!-- ANIMATED VISUAL -->
            <div class="hero-art">

                <div class="art-glow"></div>
                <div class="ring"></div>
                <div class="ring ring-two"></div>

                <div class="float-box float-box-top">
                    <strong>✦ New beginnings</strong>
                    <small>Your next opportunity awaits</small>
                </div>

                <div class="dashboard-card">

                    <div class="dashboard-head">
                        <small>CAREER DASHBOARD</small>
                        <span class="live-badge">● READY TO GROW</span>
                    </div>

                    <div class="profile">
                        <div class="avatar">🎓</div>

                        <div>
                            <h3>Your Future Starts Here</h3>
                            <p>Student career profile</p>
                        </div>
                    </div>

                    <div class="separator"></div>

                    <div class="progress-info">
                        <span>Profile completion</span>
                        <span>78%</span>
                    </div>

                    <div class="progress-bar">
                        <span></span>
                    </div>

                    <div class="skills-heading">SKILLS TO SHOWCASE</div>

                    <div class="skills">
                        <span>HTML & CSS</span>
                        <span>PHP</span>
                        <span>MySQL</span>
                        <span>Teamwork</span>
                    </div>

                </div>

                <div class="float-box float-box-bottom">
                    <strong>↗ Keep moving forward</strong>
                    <small>Learn today. Grow tomorrow.</small>
                </div>

            </div>

        </section>

        <!-- FEATURES -->
        <section class="section" id="features">

            <div class="section-heading reveal">
                <span class="section-tag">WHAT INTERNTRACK OFFERS</span>

                <h2>
                    Your Career Toolkit.<br>
                    <span class="gradient-text">All in One Place.</span>
                </h2>

                <p>
                    The essential tools to help students discover opportunities
                    and help companies connect with emerging talent.
                </p>
            </div>

            <div class="features-grid">

                <article class="feature-card reveal">
                    <div class="feature-icon">⌕</div>
                    <h3>Find Internships</h3>
                    <p>
                        Explore internship listings and discover opportunities
                        that fit your interests and career goals.
                    </p>
                </article>

                <article class="feature-card reveal">
                    <div class="feature-icon">◈</div>
                    <h3>Build Your Profile</h3>
                    <p>
                        Present your education, skills, and experience
                        through your student profile.
                    </p>
                </article>

                <article class="feature-card reveal">
                    <div class="feature-icon">↗</div>
                    <h3>Apply for Opportunities</h3>
                    <p>
                        Submit internship applications and follow your
                        application progress through your account.
                    </p>
                </article>

                <article class="feature-card reveal">
                    <div class="feature-icon">▣</div>
                    <h3>Company Dashboard</h3>
                    <p>
                        Companies can create internship listings and manage
                        the applications they receive.
                    </p>
                </article>

                <article class="feature-card reveal">
                    <div class="feature-icon">◎</div>
                    <h3>Track Applications</h3>
                    <p>
                        Keep track of application statuses and check your
                        progress from your dashboard.
                    </p>
                </article>

                <article class="feature-card reveal">
                    <div class="feature-icon">✧</div>
                    <h3>Grow Your Skills</h3>
                    <p>
                        Take the next step in your professional journey
                        by finding ways to learn and gain experience.
                    </p>
                </article>

            </div>

        </section>

        <!-- HOW IT WORKS -->
        <section class="section" id="how-it-works">

            <div class="section-heading reveal">
                <span class="section-tag">YOUR JOURNEY</span>

                <h2>
                    Three Steps to<br>
                    <span class="gradient-text">Get Started.</span>
                </h2>

                <p>
                    A simple way to start exploring internship opportunities
                    and managing your career journey.
                </p>
            </div>

            <div class="steps-grid">

                <article class="step-card reveal">
                    <div class="step-number">01</div>
                    <h3>Create Your Account</h3>
                    <p>
                        Register as a student or company and access
                        the features available for your account.
                    </p>
                </article>

                <article class="step-card reveal">
                    <div class="step-number">02</div>
                    <h3>Explore Opportunities</h3>
                    <p>
                        Students can search and apply for internships.
                        Companies can publish listings and review applicants.
                    </p>
                </article>

                <article class="step-card reveal">
                    <div class="step-number">03</div>
                    <h3>Track Your Progress</h3>
                    <p>
                        Follow your applications or manage your internship
                        listings through the appropriate dashboard.
                    </p>
                </article>

            </div>

        </section>

        <!-- CALL TO ACTION -->
        <section class="cta-section reveal">

            <div class="cta-box">

                <span class="section-tag">YOUR FUTURE IS IN MOTION</span>

                <h2>
                    Make Your Next Move<br>
                    <span class="gradient-text">Count.</span>
                </h2>

                <p>
                    Start exploring opportunities with InternTrack.<br>
                    Your career journey begins with one step.
                </p>

                <?php if ($loggedIn): ?>

                    <a href="<?= $dashboard ?>" class="btn btn-primary">
                        Open Dashboard →
                    </a>

                <?php else: ?>

                    <a href="register.php" class="btn btn-primary">
                        Create Your Account →
                    </a>

                <?php endif; ?>

            </div>

        </section>

    </main>

    <!-- FOOTER -->
    <footer class="footer">

        <a href="index.php" class="footer-brand">
            Intern<span>Track</span>
        </a>

        <p>
            © <?= date("Y") ?> InternTrack. All rights reserved.
        </p>

        <p>Built for the next generation of professionals.</p>

    </footer>

    <script>
        // Reveal content when sections enter the viewport.
        const revealElements = document.querySelectorAll(".reveal");

        if ("IntersectionObserver" in window) {

            const revealObserver = new IntersectionObserver(
                (entries, observer) => {

                    entries.forEach(entry => {

                        if (entry.isIntersecting) {
                            entry.target.classList.add("visible");
                            observer.unobserve(entry.target);
                        }

                    });

                },
                {
                    threshold: 0.12
                }
            );

            revealElements.forEach(element => {
                revealObserver.observe(element);
            });

        } else {

            revealElements.forEach(element => {
                element.classList.add("visible");
            });

        }
    </script>

</body>
</html>
