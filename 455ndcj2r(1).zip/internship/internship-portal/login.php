
<?php
session_start();
require_once __DIR__ . "/config/database.php";

if (isset($_SESSION["user_id"])) {
    $role = $_SESSION["role"] ?? "";

    if ($role === "student") {
        header("Location: student/dashboard.php");
    } elseif ($role === "company") {
        header("Location: company/dashboard.php");
    } elseif ($role === "admin") {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: index.php");
    }
    exit;
}

$error = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password === "") {
        $error = "Please enter your password.";
    } else {
        try {
            $stmt = $pdo->prepare(
                "SELECT id, name, email, password, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1"
            );

            $stmt->execute(["email" => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user["password"])) {
                session_regenerate_id(true);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["name"] = $user["name"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["role"] = $user["role"];

                if ($user["role"] === "student") {
                    header("Location: student/dashboard.php");
                } elseif ($user["role"] === "company") {
                    header("Location: company/dashboard.php");
                } elseif ($user["role"] === "admin") {
                    header("Location: admin/dashboard.php");
                } else {
                    session_unset();
                    session_destroy();
                    header("Location: login.php");
                }

                exit;
            } else {
                $error = "Incorrect email or password.";
            }
        } catch (PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            $error = "Unable to sign in right now. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | InternTrack</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #070910;
            --panel: #101421;
            --border: rgba(157, 174, 255, .15);
            --text: #f5f7ff;
            --muted: #939bb4;
            --blue: #5b8cff;
            --cyan: #47e7ff;
            --purple: #a66bff;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Inter, sans-serif;
            color: var(--text);
            background: var(--bg);
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        a { color: inherit; text-decoration: none; }

        .background-grid {
            position: fixed;
            inset: 0;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(108, 139, 255, .045) 1px, transparent 1px),
                linear-gradient(90deg, rgba(108, 139, 255, .045) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
            z-index: -2;
        }

        .glow {
            position: fixed;
            width: 360px;
            height: 360px;
            border-radius: 50%;
            filter: blur(100px);
            opacity: .22;
            pointer-events: none;
            z-index: -1;
            animation: glowMove 10s ease-in-out infinite alternate;
        }

        .glow.one { background: #4b57ff; top: -150px; left: -100px; }
        .glow.two {
            background: #9b35ff;
            bottom: -170px;
            right: -100px;
            animation-delay: -4s;
        }

        @keyframes glowMove {
            from { transform: translate(0, 0) scale(1); }
            to { transform: translate(50px, 35px) scale(1.18); }
        }

        nav {
            width: min(1120px, 92%);
            margin: 0 auto;
            padding: 24px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 11px;
            font-size: 21px;
            font-weight: 800;
            letter-spacing: -.8px;
        }

        .logo {
            width: 40px;
            height: 40px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            background: linear-gradient(135deg, #527cff, #a35bff);
            box-shadow: 0 0 25px rgba(102, 105, 255, .35);
            font-size: 17px;
            font-weight: 800;
            position: relative;
            isolation: isolate;
        }

        .logo::after {
            content: "";
            position: absolute;
            inset: -3px;
            border-radius: 15px;
            border: 1px solid rgba(100, 220, 255, .55);
            animation: logoPulse 2.5s infinite;
            z-index: -1;
        }

        @keyframes logoPulse {
            0%, 100% { transform: scale(1); opacity: .8; }
            50% { transform: scale(1.14); opacity: .2; }
        }

        .nav-note { color: var(--muted); font-size: 13px; }
        .nav-note a { color: var(--cyan); font-weight: 700; }

        main {
            flex: 1;
            display: grid;
            place-items: center;
            padding: 25px 18px 55px;
        }

        .auth-layout {
            width: min(960px, 100%);
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: center;
            gap: 55px;
            animation: appear .75s ease both;
        }

        @keyframes appear {
            from { opacity: 0; transform: translateY(22px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .intro { padding: 15px 0; }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 9px 13px;
            border: 1px solid var(--border);
            background: rgba(24, 31, 54, .65);
            border-radius: 30px;
            color: #b9c9ff;
            font-size: 11px;
            letter-spacing: 1.2px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .eyebrow span {
            width: 7px;
            height: 7px;
            background: var(--cyan);
            border-radius: 50%;
            box-shadow: 0 0 12px var(--cyan);
        }

        h1 {
            margin: 25px 0 17px;
            font-size: clamp(34px, 4vw, 49px);
            line-height: 1.12;
            letter-spacing: -2px;
        }

        .gradient-text {
            background: linear-gradient(100deg, var(--blue), var(--cyan), var(--purple));
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            animation: gradientMove 4s linear infinite;
        }

        @keyframes gradientMove {
            to { background-position: 200% center; }
        }

        .intro > p {
            max-width: 390px;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.9;
        }

        .benefits {
            display: grid;
            gap: 17px;
            margin-top: 30px;
        }

        .benefit {
            display: flex;
            gap: 13px;
            align-items: center;
            color: #d9def2;
            font-size: 13px;
        }

        .benefit-icon {
            width: 34px;
            height: 34px;
            display: grid;
            place-items: center;
            flex-shrink: 0;
            border-radius: 11px;
            background: rgba(91, 140, 255, .12);
            border: 1px solid rgba(91, 140, 255, .2);
            color: var(--cyan);
        }

        .auth-card {
            position: relative;
            padding: 34px;
            background: linear-gradient(145deg, rgba(20, 25, 43, .97), rgba(11, 14, 25, .98));
            border: 1px solid var(--border);
            border-radius: 24px;
            box-shadow: 0 25px 90px rgba(0, 0, 0, .35);
            overflow: hidden;
        }

        .auth-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 15%;
            width: 70%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), var(--purple), transparent);
        }

        .card-icon {
            width: 49px;
            height: 49px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(94, 143, 255, .25);
            background: rgba(91, 140, 255, .12);
            border-radius: 15px;
            font-size: 23px;
            margin-bottom: 20px;
        }

        .auth-card h2 { margin: 0 0 9px; font-size: 25px; letter-spacing: -.7px; }
        .subtext { color: var(--muted); font-size: 12px; line-height: 1.7; margin: 0 0 25px; }

        .alert {
            padding: 12px 14px;
            border: 1px solid rgba(255, 100, 120, .28);
            background: rgba(255, 70, 100, .08);
            color: #ff9eae;
            border-radius: 10px;
            font-size: 12px;
            line-height: 1.6;
            margin-bottom: 18px;
        }

        .field { margin-bottom: 19px; }

        label {
            display: block;
            color: #dce2f8;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 9px;
        }

        .input-wrap { position: relative; }

        input {
            width: 100%;
            padding: 14px 15px;
            color: var(--text);
            background: rgba(6, 9, 18, .75);
            border: 1px solid rgba(151, 165, 220, .17);
            border-radius: 11px;
            outline: none;
            font: inherit;
            font-size: 13px;
            transition: border-color .25s, box-shadow .25s, background .25s;
        }

        input::placeholder { color: #69718a; }

        input:focus {
            border-color: var(--blue);
            background: rgba(13, 19, 36, .95);
            box-shadow: 0 0 0 4px rgba(91, 140, 255, .10);
        }

        .password-input { padding-right: 73px; }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            border: 0;
            background: transparent;
            color: var(--cyan);
            font: inherit;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            padding: 8px 2px;
        }

        .toggle-password:hover { color: white; }

        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin: 2px 0 22px;
            color: var(--muted);
            font-size: 11px;
        }

        .remember {
            display: flex;
            gap: 7px;
            align-items: center;
            margin: 0;
            color: var(--muted);
            font-weight: 400;
        }

        .remember input { width: 14px; height: 14px; accent-color: var(--blue); }

        .primary-btn {
            width: 100%;
            padding: 15px;
            border: 0;
            border-radius: 11px;
            background: linear-gradient(100deg, #4f7cff, #8758ff);
            color: white;
            font: inherit;
            font-size: 13px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 9px 28px rgba(94, 104, 255, .23);
            transition: transform .25s, box-shadow .25s;
        }

        .primary-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 13px 34px rgba(94, 104, 255, .38);
        }

        .primary-btn:active { transform: translateY(0); }

        .switch-text {
            text-align: center;
            margin: 22px 0 0;
            color: var(--muted);
            font-size: 12px;
        }

        .switch-text a { color: var(--cyan); font-weight: 700; }
        .switch-text a:hover { text-decoration: underline; }

        footer {
            padding: 18px;
            text-align: center;
            color: #68718a;
            font-size: 11px;
        }

        @media (max-width: 760px) {
            .auth-layout { grid-template-columns: 1fr; gap: 25px; max-width: 440px; }
            .intro { text-align: center; padding: 0; }
            .intro > p { margin: 0 auto; }
            .benefits { display: none; }
            h1 { font-size: 36px; margin: 18px 0 12px; }
            .auth-card { padding: 27px 23px; }
            nav { padding: 18px 0; }
            .nav-note { font-size: 11px; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
    <link rel="stylesheet" href="css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/includes/galaxy_bg.php'; ?>
    <div class="background-grid"></div>
    <div class="glow one"></div>
    <div class="glow two"></div>

    <nav>
        <a class="brand" href="index.php">
            <span class="logo">IT</span>
            <span>Intern<span class="gradient-text">Track</span></span>
        </a>
        <div class="nav-note">
            New here? <a href="register.php">Create account ↗</a>
        </div>
    </nav>

    <main>
        <div class="auth-layout">
            <section class="intro">
                <div class="eyebrow"><span></span> YOUR NEXT CHAPTER STARTS HERE</div>
                <h1>Welcome back.<br>Let's build your <span class="gradient-text">future.</span></h1>
                <p>
                    Sign in to discover opportunities, manage your applications,
                    and take the next step in your career journey.
                </p>

                <div class="benefits">
                    <div class="benefit">
                        <span class="benefit-icon">✦</span>
                        <span>Discover internship opportunities</span>
                    </div>
                    <div class="benefit">
                        <span class="benefit-icon">↗</span>
                        <span>Track your application progress</span>
                    </div>
                    <div class="benefit">
                        <span class="benefit-icon">⌘</span>
                        <span>Build your professional future</span>
                    </div>
                </div>
            </section>

            <section class="auth-card">
                <div class="card-icon">✦</div>
                <h2>Sign in</h2>
                <p class="subtext">Enter your account details to continue.</p>

                <?php if ($error !== ""): ?>
                    <div class="alert" role="alert">
                        <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <div class="field">
                        <label for="email">Email address</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="you@example.com"
                            value="<?= htmlspecialchars($email, ENT_QUOTES, "UTF-8") ?>"
                            autocomplete="email"
                            maxlength="254"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="password">Password</label>
                        <div class="input-wrap">
                            <input
                                class="password-input"
                                type="password"
                                id="password"
                                name="password"
                                placeholder="Enter your password"
                                autocomplete="current-password"
                                required
                            >
                            <button
                                class="toggle-password"
                                type="button"
                                data-target="password"
                                aria-controls="password"
                                aria-pressed="false"
                            >Show</button>
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="remember">
                            <input type="checkbox" name="remember_email" value="1">
                            Remember email
                        </label>
                        <span>Secure sign in</span>
                    </div>

                    <button class="primary-btn" type="submit">Sign In &nbsp; →</button>
                </form>

                <p class="switch-text">
                    Don't have an account? <a href="register.php">Create one</a>
                </p>
            </section>
        </div>
    </main>

    <footer>© <?= date("Y") ?> InternTrack · Your career journey starts here.</footer>

    <script>
        document.querySelectorAll(".toggle-password").forEach(function (button) {
            button.addEventListener("click", function () {
                const input = document.getElementById(button.dataset.target);
                const showing = input.type === "text";

                input.type = showing ? "password" : "text";
                button.textContent = showing ? "Show" : "Hide";
                button.setAttribute("aria-pressed", String(!showing));
            });
        });
    </script>
</body>
</html>
