
<?php
session_start();
require_once __DIR__ . "/config/database.php";

if (isset($_SESSION["user_id"])) {
    $role = $_SESSION["role"] ?? "";

    if ($role === "student") {
        header("Location: student/dashboard.php");
    } elseif ($role === "company") {
        header("Location: company/dashboard.php");
    } elseif ($role === "admin") {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: index.php");
    }
    exit;
}

$error = "";
$name = "";
$email = "";
$companyName = "";
$role = "student";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $companyName = trim($_POST["company_name"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";
    $role = $_POST["role"] ?? "student";

    if ($name === "" || strlen($name) > 100) {
        $error = "Enter your name (maximum 100 characters).";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $error = "Enter a valid email address.";
    } elseif (!in_array($role, ["student", "company"], true)) {
        $error = "Please select a valid account type.";
    } elseif ($role === "company" && ($companyName === "" || strlen($companyName) > 150)) {
        $error = "Enter your company name (maximum 150 characters).";
    } elseif (strlen($password) < 8) {
        $error = "Password must contain at least 8 characters.";
    } elseif (strlen($password) > 4096) {
        $error = "Password is too long.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        try {
            $pdo->beginTransaction();

            $check = $pdo->prepare(
                "SELECT id FROM users WHERE email = :email LIMIT 1"
            );
            $check->execute(["email" => $email]);

            if ($check->fetch()) {
                $pdo->rollBack();
                $error = "This email address is already registered.";
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare(
                    "INSERT INTO users (name, email, password, role)
                     VALUES (:name, :email, :password, :role)"
                );

                $stmt->execute([
                    "name" => $name,
                    "email" => $email,
                    "password" => $hashedPassword,
                    "role" => $role
                ]);

                $userId = $pdo->lastInsertId();

                if ($role === "student") {
                    $profile = $pdo->prepare(
                        "INSERT INTO students (user_id) VALUES (:user_id)"
                    );
                    $profile->execute(["user_id" => $userId]);
                } else {
                    $profile = $pdo->prepare(
                        "INSERT INTO companies (user_id, company_name)
                         VALUES (:user_id, :company_name)"
                    );
                    $profile->execute([
                        "user_id" => $userId,
                        "company_name" => $companyName
                    ]);
                }

                $pdo->commit();

                session_regenerate_id(true);
                $_SESSION["user_id"] = $userId;
                $_SESSION["name"] = $name;
                $_SESSION["email"] = $email;
                $_SESSION["role"] = $role;

                if ($role === "student") {
                    header("Location: student/dashboard.php");
                } else {
                    header("Location: company/dashboard.php");
                }
                exit;
            }
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("Registration error: " . $e->getMessage());
            $error = "Registration failed. Please check your database and try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | InternTrack</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #070910;
            --border: rgba(157, 174, 255, .15);
            --text: #f5f7ff;
            --muted: #939bb4;
            --blue: #5b8cff;
            --cyan: #47e7ff;
            --purple: #a66bff;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Inter, sans-serif;
            color: var(--text);
            background: var(--bg);
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        a { color: inherit; text-decoration: none; }

        .background-grid {
            position: fixed;
            inset: 0;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(108,139,255,.045) 1px, transparent 1px),
                linear-gradient(90deg, rgba(108,139,255,.045) 1px, transparent 1px);
            background-size: 48px 48px;
            z-index: -2;
        }

        .glow {
            position: fixed;
            width: 350px;
            height: 350px;
            border-radius: 50%;
            filter: blur(100px);
            opacity: .2;
            pointer-events: none;
            z-index: -1;
            animation: glowMove 9s ease-in-out infinite alternate;
        }

        .glow.one { background: #4b57ff; top: -150px; left: -100px; }
        .glow.two {
            background: #9b35ff;
            bottom: -170px;
            right: -100px;
            animation-delay: -4s;
        }

        @keyframes glowMove {
            from { transform: translate(0,0) scale(1); }
            to { transform: translate(45px,30px) scale(1.15); }
        }

        nav {
            width: min(1120px, 92%);
            margin: 0 auto;
            padding: 23px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 11px;
            font-size: 21px;
            font-weight: 800;
            letter-spacing: -.8px;
        }

        .logo {
            width: 40px;
            height: 40px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            background: linear-gradient(135deg, #527cff, #a35bff);
            box-shadow: 0 0 25px rgba(102,105,255,.35);
            position: relative;
            isolation: isolate;
        }

        .logo::after {
            content: "";
            position: absolute;
            inset: -3px;
            border: 1px solid rgba(100,220,255,.6);
            border-radius: 15px;
            animation: pulse 2.5s infinite;
            z-index: -1;
        }

        @keyframes pulse {
            0%,100% { transform: scale(1); opacity: .8; }
            50% { transform: scale(1.13); opacity: .2; }
        }

        .gradient-text {
            background: linear-gradient(100deg, var(--blue), var(--cyan), var(--purple));
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            animation: gradientMove 4s linear infinite;
        }

        @keyframes gradientMove {
            to { background-position: 200% center; }
        }

        .nav-note { color: var(--muted); font-size: 12px; }
        .nav-note a { color: var(--cyan); font-weight: 700; }

        main {
            flex: 1;
            display: grid;
            place-items: center;
            padding: 20px 18px 45px;
        }

        .layout {
            width: min(950px, 100%);
            display: grid;
            grid-template-columns: .9fr 1.1fr;
            align-items: center;
            gap: 50px;
            animation: appear .7s ease both;
        }

        @keyframes appear {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 9px 13px;
            border: 1px solid var(--border);
            background: rgba(24,31,54,.65);
            border-radius: 30px;
            color: #b9c9ff;
            font-size: 10px;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--cyan);
            box-shadow: 0 0 12px var(--cyan);
        }

        h1 {
            margin: 24px 0 15px;
            font-size: clamp(34px, 4vw, 48px);
            line-height: 1.15;
            letter-spacing: -2px;
        }

        .intro > p {
            max-width: 380px;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.9;
        }

        .steps { display: grid; gap: 16px; margin-top: 28px; }

        .step {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #d9def2;
            font-size: 12px;
        }

        .step-icon {
            width: 35px;
            height: 35px;
            display: grid;
            place-items: center;
            border-radius: 11px;
            color: var(--cyan);
            background: rgba(91,140,255,.12);
            border: 1px solid rgba(91,140,255,.2);
        }

        .card {
            position: relative;
            padding: 30px;
            background: linear-gradient(145deg, rgba(20,25,43,.97), rgba(11,14,25,.98));
            border: 1px solid var(--border);
            border-radius: 23px;
            box-shadow: 0 25px 90px rgba(0,0,0,.35);
            overflow: hidden;
        }

        .card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 15%;
            width: 70%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), var(--purple), transparent);
        }

        .card-icon {
            width: 45px;
            height: 45px;
            display: grid;
            place-items: center;
            border-radius: 14px;
            background: rgba(91,140,255,.12);
            border: 1px solid rgba(91,140,255,.25);
            margin-bottom: 16px;
            font-size: 21px;
        }

        h2 { margin: 0 0 8px; font-size: 24px; letter-spacing: -.6px; }
        .subtext { color: var(--muted); font-size: 12px; margin: 0 0 22px; line-height: 1.7; }

        .alert {
            padding: 12px;
            margin-bottom: 16px;
            border-radius: 10px;
            border: 1px solid rgba(255,100,120,.28);
            background: rgba(255,70,100,.08);
            color: #ff9eae;
            font-size: 12px;
            line-height: 1.6;
        }

        .field { margin-bottom: 16px; }

        label {
            display: block;
            margin-bottom: 8px;
            color: #dce2f8;
            font-size: 12px;
            font-weight: 600;
        }

        input, select {
            width: 100%;
            padding: 13px 14px;
            border: 1px solid rgba(151,165,220,.17);
            border-radius: 11px;
            outline: none;
            background: rgba(6,9,18,.75);
            color: var(--text);
            font: inherit;
            font-size: 12px;
            transition: border-color .25s, box-shadow .25s;
        }

        input::placeholder { color: #69718a; }

        input:focus, select:focus {
            border-color: var(--blue);
            box-shadow: 0 0 0 4px rgba(91,140,255,.10);
        }

        select { cursor: pointer; }
        select option { background: #101421; color: white; }

        .input-wrap { position: relative; }
        .password-input { padding-right: 70px; }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            background: none;
            border: 0;
            color: var(--cyan);
            cursor: pointer;
            font: inherit;
            font-size: 11px;
            font-weight: 700;
        }

        .strength { margin-top: 9px; }
        .strength-bars { display: flex; gap: 5px; }
        .strength-bars span {
            flex: 1;
            height: 4px;
            border-radius: 5px;
            background: #293047;
            transition: background .2s;
        }

        .strength-label { margin-top: 6px; color: var(--muted); font-size: 10px; }

        .terms {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            margin: 5px 0 18px;
            color: var(--muted);
            font-size: 10px;
            line-height: 1.7;
            font-weight: 400;
        }

        .terms input {
            width: 14px;
            height: 14px;
            flex-shrink: 0;
            margin: 2px 0 0;
            accent-color: var(--blue);
        }

        .primary-btn {
            width: 100%;
            padding: 15px;
            border: 0;
            border-radius: 11px;
            background: linear-gradient(100deg, #4f7cff, #8758ff);
            color: white;
            font: inherit;
            font-size: 13px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 9px 28px rgba(94,104,255,.23);
            transition: transform .25s, box-shadow .25s;
        }

        .primary-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 13px 34px rgba(94,104,255,.38);
        }

        .switch-text {
            text-align: center;
            margin: 20px 0 0;
            color: var(--muted);
            font-size: 11px;
        }

        .switch-text a { color: var(--cyan); font-weight: 700; }
        footer { padding: 18px; text-align: center; color: #68718a; font-size: 10px; }

        @media (max-width: 760px) {
            .layout { grid-template-columns: 1fr; gap: 22px; max-width: 440px; }
            .intro { text-align: center; }
            .intro > p { margin: 0 auto; }
            .steps { display: none; }
            h1 { font-size: 35px; margin: 17px 0 12px; }
            .card { padding: 25px 21px; }
            nav { padding: 18px 0; }
            .nav-note { font-size: 10px; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
    <link rel="stylesheet" href="css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/includes/galaxy_bg.php'; ?>
    <div class="background-grid"></div>
    <div class="glow one"></div>
    <div class="glow two"></div>

    <nav>
        <a class="brand" href="index.php">
            <span class="logo">IT</span>
            <span>Intern<span class="gradient-text">Track</span></span>
        </a>
        <div class="nav-note">
            Already registered? <a href="login.php">Sign in ↗</a>
        </div>
    </nav>

    <main>
        <div class="layout">
            <section class="intro">
                <div class="eyebrow"><span class="dot"></span> START YOUR JOURNEY</div>
                <h1>Your future.<br>Your skills.<br>Your <span class="gradient-text">opportunity.</span></h1>
                <p>
                    Create your InternTrack account and take the next step
                    toward connecting talent with opportunity.
                </p>

                <div class="steps">
                    <div class="step"><span class="step-icon">01</span><span>Create your account</span></div>
                    <div class="step"><span class="step-icon">02</span><span>Discover new opportunities</span></div>
                    <div class="step"><span class="step-icon">03</span><span>Move your career forward</span></div>
                </div>
            </section>

            <section class="card">
                <div class="card-icon">✦</div>
                <h2>Create your account</h2>
                <p class="subtext">Join InternTrack. It only takes a minute.</p>

                <?php if ($error !== ""): ?>
                    <div class="alert" role="alert">
                        <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="register.php" id="registerForm">
                    <div class="field">
                        <label for="name">Full name</label>
                        <input
                            type="text" id="name" name="name"
                            placeholder="Enter your full name"
                            value="<?= htmlspecialchars($name, ENT_QUOTES, "UTF-8") ?>"
                            maxlength="100" autocomplete="name" required
                        >
                    </div>

                    <div class="field">
                        <label for="email">Email address</label>
                        <input
                            type="email" id="email" name="email"
                            placeholder="you@example.com"
                            value="<?= htmlspecialchars($email, ENT_QUOTES, "UTF-8") ?>"
                            maxlength="150" autocomplete="email" required
                        >
                    </div>

                    <div class="field">
                        <label for="role">I want to join as</label>
                        <select id="role" name="role" required>
                            <option value="student" <?= $role === "student" ? "selected" : "" ?>>
                                Student — Find internships
                            </option>
                            <option value="company" <?= $role === "company" ? "selected" : "" ?>>
                                Company — Post internships
                            </option>
                        </select>
                    </div>

                    <div class="field" id="companyField" hidden>
                        <label for="company_name">Company name</label>
                        <input
                            type="text" id="company_name" name="company_name"
                            placeholder="Enter your company name"
                            maxlength="150" autocomplete="organization"
                            disabled
                        >
                    </div>

                    <div class="field">
                        <label for="password">Create password</label>
                        <div class="input-wrap">
                            <input
                                class="password-input" type="password"
                                id="password" name="password"
                                placeholder="At least 8 characters"
                                minlength="8" maxlength="4096"
                                autocomplete="new-password" required
                            >
                            <button class="toggle-password" type="button"
                                data-target="password" aria-controls="password"
                                aria-pressed="false">Show</button>
                        </div>

                        <div class="strength">
                            <div class="strength-bars">
                                <span></span><span></span><span></span><span></span>
                            </div>
                            <div class="strength-label" id="strengthLabel">
                                Use at least 8 characters.
                            </div>
                        </div>
                    </div>

                    <div class="field">
                        <label for="confirm_password">Confirm password</label>
                        <div class="input-wrap">
                            <input
                                class="password-input" type="password"
                                id="confirm_password" name="confirm_password"
                                placeholder="Enter your password again"
                                maxlength="4096" autocomplete="new-password" required
                            >
                            <button class="toggle-password" type="button"
                                data-target="confirm_password" aria-controls="confirm_password"
                                aria-pressed="false">Show</button>
                        </div>
                    </div>

                    <label class="terms">
                        <input type="checkbox" id="terms" required>
                        <span>I confirm that the details provided are correct and agree to use InternTrack responsibly.</span>
                    </label>

                    <button class="primary-btn" type="submit">Create Account &nbsp; →</button>
                </form>

                <p class="switch-text">
                    Already have an account? <a href="login.php">Sign in</a>
                </p>
            </section>
        </div>
    </main>

    <footer>© <?= date("Y") ?> InternTrack · Build your future.</footer>

    <script>
        // Show / Hide passwords
        document.querySelectorAll(".toggle-password").forEach(function (button) {
            button.addEventListener("click", function () {
                const input = document.getElementById(button.dataset.target);
                const showing = input.type === "text";

                input.type = showing ? "password" : "text";
                button.textContent = showing ? "Show" : "Hide";
                button.setAttribute("aria-pressed", String(!showing));
            });
        });

        // Show company name only when Company is selected
        const roleSelect = document.getElementById("role");
        const companyField = document.getElementById("companyField");
        const companyNameInput = document.getElementById("company_name");

        function updateCompanyField() {
            const isCompany = roleSelect.value === "company";
            companyField.hidden = !isCompany;
            companyNameInput.disabled = !isCompany;
            companyNameInput.required = isCompany;
        }

        roleSelect.addEventListener("change", updateCompanyField);
        updateCompanyField();

        // Password strength indicator
        const passwordInput = document.getElementById("password");
        const strengthBars = document.querySelectorAll(".strength-bars span");
        const strengthLabel = document.getElementById("strengthLabel");

        passwordInput.addEventListener("input", function () {
            const value = passwordInput.value;
            let score = 0;

            if (value.length >= 8) score++;
            if (value.length >= 12) score++;
            if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
            if (/[0-9]/.test(value) && /[^a-zA-Z0-9]/.test(value)) score++;

            const labels = [
                "Use at least 8 characters.",
                "Weak password",
                "Fair password",
                "Good password",
                "Strong password"
            ];

            strengthLabel.textContent = labels[score];

            strengthBars.forEach(function (bar, index) {
                bar.style.background = index < score
                    ? (score <= 1 ? "#ff647c" : score === 2 ? "#ffbd59" : "#47e7ff")
                    : "#293047";
            });
        });

        // Check password confirmation before submitting
        document.getElementById("registerForm").addEventListener("submit", function (event) {
            const password = passwordInput.value;
            const confirmPassword = document.getElementById("confirm_password").value;

            if (password !== confirmPassword) {
                event.preventDefault();
                alert("Passwords do not match. Please check and try again.");
                document.getElementById("confirm_password").focus();
            }
        });
    </script>
</body>
</html>
