const display = document.getElementById('display');
const secretTrigger = document.getElementById('secret-trigger');
const secretImage = document.getElementById('secret-image');
const secretGallery = document.getElementById('secret-gallery');
const galleryClose = document.querySelector('.gallery-close');
const imagePreview = document.getElementById('image-preview');
const previewImage = document.getElementById('preview-image');
const previewArt = document.getElementById('preview-art');
const previewTitle = document.getElementById('preview-title');
const previewClose = document.getElementById('preview-close');
const passwordDialog = document.getElementById('password-dialog');
const passwordForm = document.getElementById('password-form');
const passwordInput = document.getElementById('gallery-password');
const passwordTitle = document.getElementById('password-title');
const passwordInstructions = document.getElementById('password-instructions');
const passwordLabel = document.getElementById('password-label');
const passwordStatus = document.getElementById('password-status');
const passwordCancel = document.getElementById('password-cancel');
const forgotPassword = document.getElementById('forgot-password');
const recoveryDialog = document.getElementById('recovery-dialog');
const recoveryCodeDisplay = document.getElementById('recovery-code');
const recoveryContinue = document.getElementById('recovery-continue');
const passwordStorageKey = 'calculator-gallery-password';
let passwordMode = 'unlock';
let titleClicks = 0;
let expression = '';

secretTrigger.addEventListener('click', () => {
  titleClicks += 1;
  if (titleClicks === 5) {
    secretImage.classList.add('visible');
    secretImage.setAttribute('aria-hidden', 'false');
    secretImage.removeAttribute('tabindex');
  }
});

function getPasswordRecord() {
  try {
    return JSON.parse(localStorage.getItem(passwordStorageKey) || 'null');
  } catch {
    return null;
  }
}

async function hashPassword(password, salt) {
  const bytes = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function createRecoveryRecord() {
  const code = Array.from(crypto.getRandomValues(new Uint8Array(8)), (byte) => byte.toString(16).padStart(2, '0')).join('').toUpperCase();
  const salt = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, '0')).join('');
  return hashPassword(code, salt).then((hash) => ({ code, recoverySalt: salt, recoveryHash: hash }));
}

function showRecoveryCode(code) {
  recoveryCodeDisplay.textContent = code.match(/.{1,4}/g).join('-');
  passwordDialog.close();
  recoveryDialog.showModal();
}

function showGallery() {
  secretGallery.showModal();
}

secretImage.addEventListener('click', () => {
  const record = getPasswordRecord();
  passwordMode = record ? 'unlock' : 'set';
  passwordTitle.textContent = record ? 'Unlock hidden images' : 'Set your gallery password';
  passwordInstructions.textContent = record
    ? 'Enter your password to open hidden image storage.'
    : 'Create a password to protect your hidden images.';
  passwordLabel.textContent = 'Password';
  passwordInput.type = 'password';
  passwordInput.autocomplete = record ? 'current-password' : 'new-password';
  passwordInput.value = '';
  passwordStatus.textContent = '';
  forgotPassword.hidden = !record || !record.recoveryHash;
  passwordDialog.showModal();
  passwordInput.focus();
});

forgotPassword.addEventListener('click', () => {
  passwordMode = 'recover';
  passwordTitle.textContent = 'Recover gallery access';
  passwordInstructions.textContent = 'Enter the recovery code you saved to choose a new password.';
  passwordLabel.textContent = 'Recovery code';
  passwordInput.type = 'text';
  passwordInput.autocomplete = 'off';
  passwordInput.value = '';
  passwordStatus.textContent = '';
  forgotPassword.hidden = true;
  passwordInput.focus();
});

passwordForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const value = passwordInput.value.trim();
  if (!value) return;

  try {
    if (!crypto.subtle) throw new Error('Password hashing is unavailable.');

    if (passwordMode === 'set') {
      const record = await createRecoveryRecord();
      const salt = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, '0')).join('');
      const hash = await hashPassword(value, salt);
      localStorage.setItem(passwordStorageKey, JSON.stringify({ salt, hash, recoverySalt: record.recoverySalt, recoveryHash: record.recoveryHash }));
      showRecoveryCode(record.code);
      return;
    }

    if (passwordMode === 'unlock') {
      const record = getPasswordRecord();
      if (!record || await hashPassword(value, record.salt) !== record.hash) {
        passwordStatus.textContent = 'That password is not correct.';
        passwordInput.select();
        return;
      }

      if (!record.recoveryHash) {
        const recovery = await createRecoveryRecord();
        localStorage.setItem(passwordStorageKey, JSON.stringify({ ...record, recoverySalt: recovery.recoverySalt, recoveryHash: recovery.recoveryHash }));
        showRecoveryCode(recovery.code);
        return;
      }

      passwordDialog.close();
      showGallery();
      return;
    }

    const record = getPasswordRecord();
    if (passwordMode === 'recover') {
      const code = value.replaceAll('-', '').toUpperCase();
      if (!record?.recoveryHash || await hashPassword(code, record.recoverySalt) !== record.recoveryHash) {
        passwordStatus.textContent = 'That recovery code is not correct.';
        passwordInput.select();
        return;
      }
      passwordMode = 'recover-set';
      passwordTitle.textContent = 'Set a new password';
      passwordInstructions.textContent = 'Choose a new password for your hidden images.';
      passwordLabel.textContent = 'New password';
      passwordInput.type = 'password';
      passwordInput.autocomplete = 'new-password';
      passwordInput.value = '';
      passwordStatus.textContent = 'Recovery code accepted.';
      passwordInput.focus();
      return;
    }

    if (passwordMode === 'recover-set' && record) {
      const salt = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, '0')).join('');
      const hash = await hashPassword(value, salt);
      localStorage.setItem(passwordStorageKey, JSON.stringify({ ...record, salt, hash }));
      passwordDialog.close();
      showGallery();
    }
  } catch {
    passwordStatus.textContent = 'Could not save or check your password in this browser.';
  }
});

passwordCancel.addEventListener('click', () => passwordDialog.close());
recoveryContinue.addEventListener('click', () => {
  recoveryDialog.close();
  showGallery();
});
recoveryDialog.addEventListener('cancel', (event) => event.preventDefault());
galleryClose.addEventListener('click', () => secretGallery.close());
secretGallery.addEventListener('click', (event) => {
  if (event.target === secretGallery) {
    secretGallery.close();
    return;
  }

  const item = event.target.closest('.gallery-item, .saved-image-card img');
  if (!item) return;

  previewTitle.textContent = item.classList.contains('gallery-item')
    ? 'Secret cat'
    : item.alt;
  previewImage.hidden = true;
  previewImage.removeAttribute('src');
  previewArt.replaceChildren();

  if (item.tagName === 'IMG') {
    previewImage.src = item.src;
    previewImage.alt = item.alt;
    previewImage.hidden = false;
  } else {
    previewArt.append(item.querySelector('svg').cloneNode(true));
  }

  imagePreview.showModal();
});
secretGallery.addEventListener('keydown', (event) => {
  if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('.gallery-item, .saved-image-card img')) {
    event.preventDefault();
    event.target.click();
  }
});
previewClose.addEventListener('click', () => imagePreview.close());
imagePreview.addEventListener('click', (event) => {
  if (event.target === imagePreview) imagePreview.close();
});

const imageUpload = document.getElementById('image-upload');
const savedImages = document.getElementById('saved-images');
const galleryStatus = document.getElementById('gallery-status');
const imageStorageKey = 'calculator-hidden-images';

function loadSavedImages() {
  try {
    return JSON.parse(localStorage.getItem(imageStorageKey) || '[]');
  } catch {
    return [];
  }
}

function renderSavedImages() {
  savedImages.replaceChildren();
  loadSavedImages().forEach((image, index) => {
    const card = document.createElement('div');
    card.className = 'saved-image-card';

    const img = document.createElement('img');
    img.src = image.data;
    img.alt = image.name;
    img.tabIndex = 0;
    img.setAttribute('role', 'button');
    img.setAttribute('aria-label', `View ${image.name} larger`);

    const name = document.createElement('p');
    name.textContent = image.name;

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.textContent = 'Remove';
    removeButton.setAttribute('aria-label', `Remove ${image.name}`);
    removeButton.addEventListener('click', () => {
      const images = loadSavedImages();
      images.splice(index, 1);
      try {
        localStorage.setItem(imageStorageKey, JSON.stringify(images));
        renderSavedImages();
        galleryStatus.textContent = 'Image removed.';
      } catch {
        galleryStatus.textContent = 'Could not update saved images in this browser.';
      }
    });

    card.append(img, name, removeButton);
    savedImages.append(card);
  });
}

imageUpload.addEventListener('change', () => {
  const files = Array.from(imageUpload.files || []).filter((file) => file.type.startsWith('image/'));
  if (!files.length) return;

  Promise.all(files.map((file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ name: file.name, data: reader.result });
    reader.onerror = reject;
    reader.readAsDataURL(file);
  })))
    .then((newImages) => {
      try {
        const images = [...loadSavedImages(), ...newImages];
        localStorage.setItem(imageStorageKey, JSON.stringify(images));
        renderSavedImages();
        galleryStatus.textContent = `${newImages.length} image${newImages.length === 1 ? '' : 's'} saved in this browser.`;
      } catch {
        galleryStatus.textContent = 'Could not save images. Try smaller images or remove some saved images.';
      }
    })
    .catch(() => {
      galleryStatus.textContent = 'Could not read one of the selected images.';
    })
    .finally(() => {
      imageUpload.value = '';
    });
});

renderSavedImages();

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {
      // Offline caching is optional; the calculator still works if registration fails.
    });
  });
}

let justCalculated = false;

function updateDisplay(value = expression || '0') {
  display.value = value.replaceAll('*', '×').replaceAll('/', '÷');
}

function calculate() {
  if (!expression || /[+*/.-]$/.test(expression)) return;

  const parts = expression.match(/(?:\d+\.?\d*|\.\d+)|[+*/-]/g);
  if (!parts || parts.join('') !== expression) return;

  const values = [];
  const operators = [];
  const precedence = { '+': 1, '-': 1, '*': 2, '/': 2 };
  const apply = () => {
    const operator = operators.pop();
    const right = values.pop();
    const left = values.pop();
    if (operator === '+') values.push(left + right);
    if (operator === '-') values.push(left - right);
    if (operator === '*') values.push(left * right);
    if (operator === '/') values.push(left / right);
  };

  let expectingNumber = true;
  for (const part of parts) {
    if (!Number.isNaN(Number(part))) {
      values.push(Number(part));
      expectingNumber = false;
    } else if (expectingNumber && part === '-') {
      values.push(0);
      operators.push('-');
    } else {
      while (operators.length && precedence[operators.at(-1)] >= precedence[part]) apply();
      operators.push(part);
      expectingNumber = true;
    }
  }

  while (operators.length) apply();
  const result = values[0];
  if (!Number.isFinite(result)) {
    expression = '';
    updateDisplay('Error');
  } else {
    expression = String(Number(result.toPrecision(12)));
    updateDisplay();
  }
  justCalculated = true;
}

document.querySelector('.buttons').addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) return;

  const { action, value } = button.dataset;
  if (action === 'clear') {
    expression = '';
    justCalculated = false;
    updateDisplay();
    return;
  }
  if (action === 'delete') {
    expression = expression.slice(0, -1);
    justCalculated = false;
    updateDisplay();
    return;
  }
  if (action === 'equals') {
    calculate();
    return;
  }

  if (justCalculated && /\d|\./.test(value)) expression = '';
  justCalculated = false;
  if (/[+*/-]/.test(value) && /[+*/-]$/.test(expression)) {
    expression = expression.slice(0, -1);
  }
  if (value === '.' && /(?:^|[+*/-])\d*\.\d*$/.test(expression)) return;
  expression += value;
  updateDisplay();
});
