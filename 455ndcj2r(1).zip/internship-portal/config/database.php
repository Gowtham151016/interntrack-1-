
<?php
/**
 * InternTrack - Database Configuration and Shared Helpers
 * File: config/database.php
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ==========================================
// 1. DATABASE CONFIGURATION
// ==========================================

$host = "db01.dbhost.dev";
$dbname = "db_455a2gvcw";
$username = "user_455a2gvcw";
$password = "REPLACE_WITH_YOUR_ROTATED_PASSWORD";
$port = 5051;

$dbError = null;
$pdo = null;

// ==========================================
// 2. PDO CONNECTION
// ==========================================

try {
    $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";

    $pdo = new PDO(
        $dsn,
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 10
        ]
    );
} catch (PDOException $exception) {
    $dbError = 'Database connection is unavailable. Please try again later.';

    error_log(
        'InternTrack DB ERROR: ' . $exception->getMessage()
    );

    $pdo = null;
}

// ==========================================
// 3. HTML ESCAPING
// ==========================================

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// ==========================================
// 4. ROLE AUTHORIZATION
// ==========================================

if (!function_exists('require_role')) {
    function require_role(string $role): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (
            !isset($_SESSION['user_id'], $_SESSION['role']) ||
            !is_numeric($_SESSION['user_id']) ||
            (int) $_SESSION['user_id'] < 1 ||
            !is_string($_SESSION['role']) ||
            $_SESSION['role'] !== $role
        ) {
            $script = str_replace(
                '\\',
                '/',
                $_SERVER['SCRIPT_NAME'] ?? ''
            );

            $basePath = dirname(dirname($script));

            if ($basePath === '/' || $basePath === '.') {
                $basePath = '';
            }

            header('Location: ' . $basePath . '/login.php');
            exit;
        }
    }
}

// ==========================================
// 5. CREATE FLASH MESSAGE
// ==========================================

if (!function_exists('flash')) {
    function flash(string $type, string $message): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['flash'][$type] = $message;
    }
}

// ==========================================
// 6. RETRIEVE FLASH MESSAGE
// ==========================================

if (!function_exists('take_flash')) {
    function take_flash(): ?array
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $flashes = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);

        if (!is_array($flashes) || $flashes === []) {
            return null;
        }

        // Support a single message stored as an array.
        if (
            isset($flashes['type'], $flashes['message']) &&
            is_string($flashes['type']) &&
            is_string($flashes['message'])
        ) {
            return [
                'type' => $flashes['type'],
                'message' => $flashes['message']
            ];
        }

        // Support flash('success', 'Message').
        foreach ($flashes as $type => $message) {
            if (is_string($message)) {
                return [
                    'type' => (string) $type,
                    'message' => $message
                ];
            }
        }

        return null;
    }
}

// ==========================================
// 7. APPLICATION STATUS CSS CLASS
// ==========================================

if (!function_exists('status_class')) {
    function status_class(string $status): string
    {
        $classes = [
            'Applied'      => 'applied',
            'Under Review' => 'under-review',
            'Shortlisted'  => 'shortlisted',
            'Interview'    => 'interview',
            'Selected'     => 'selected',
            'Rejected'     => 'rejected',
            'Open'         => 'open',
            'Closed'       => 'rejected'
        ];

        return $classes[$status] ?? 'applied';
    }
}
