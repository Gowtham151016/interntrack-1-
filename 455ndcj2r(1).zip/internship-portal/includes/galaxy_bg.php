<?php
/*
 * Shared animated galaxy background (decorative only).
 * Include once, right after the opening <body> tag, and load css/galaxy.css.
 */
?>
<div class="galaxy-bg" aria-hidden="true">
    <div class="gx-nebula gx-nebula-a"></div>
    <div class="gx-nebula gx-nebula-b"></div>

    <div class="gx-rotor"><div class="gx-stars gx-stars-far"></div></div>
    <div class="gx-stars gx-twinkle gx-twinkle-a"></div>
    <div class="gx-stars gx-twinkle gx-twinkle-b"></div>

    <div class="gx-galaxy">
        <div class="gx-galaxy-tilt">
            <div class="gx-galaxy-spin"></div>
        </div>
    </div>

    <div class="gx-system">
        <div class="gx-ring gx-ring-back"></div>
        <div class="gx-planet">
            <div class="gx-planet-surface"></div>
        </div>
        <div class="gx-ring gx-ring-front"></div>
        <div class="gx-orbit">
            <div class="gx-moon"></div>
        </div>
    </div>

    <span class="gx-comet gx-comet-1"></span>
    <span class="gx-comet gx-comet-2"></span>
    <span class="gx-comet gx-comet-3"></span>

    <div class="gx-veil"></div>
</div>
