<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

require_role('company');

$allowed = [
    'Applied',
    'Under Review',
    'Shortlisted',
    'Interview',
    'Selected',
    'Rejected'
];

$rows = [];
$error = '';
$message = '';
$companyId = 0;

if (!isset($dbError)) {
    $dbError = null;
}

if (!isset($pdo) || !$pdo instanceof PDO) {
    $error = $dbError ?: 'Database connection is unavailable.';
} else {
    try {
        // Find the company associated with the logged-in account.
        $stmt = $pdo->prepare(
            'SELECT id
             FROM companies
             WHERE user_id = :uid
             LIMIT 1'
        );

        $stmt->execute([
            'uid' => (int) $_SESSION['user_id']
        ]);

        $companyId = (int) $stmt->fetchColumn();

        if ($companyId < 1) {
            $error = 'A company profile was not found for this account.';
        } else {
            // Update an application status.
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $applicationId = filter_input(
                    INPUT_POST,
                    'application_id',
                    FILTER_VALIDATE_INT
                );

                $newStatus = trim(
                    (string) ($_POST['status'] ?? '')
                );

                if (!$applicationId || $applicationId < 1) {
                    $message = 'Please select a valid application.';
                } elseif (!in_array($newStatus, $allowed, true)) {
                    $message = 'Please choose a valid application status.';
                } else {
                    // Verify that this application belongs to this company.
                    $check = $pdo->prepare(
                        'SELECT a.id
                         FROM applications a
                         INNER JOIN internships i
                             ON i.id = a.internship_id
                         WHERE a.id = :aid
                           AND i.company_id = :cid
                         LIMIT 1'
                    );

                    $check->execute([
                        'aid' => $applicationId,
                        'cid' => $companyId
                    ]);

                    if ($check->fetchColumn()) {
                        $update = $pdo->prepare(
                            'UPDATE applications
                             SET status = :status
                             WHERE id = :aid'
                        );

                        $update->execute([
                            'status' => $newStatus,
                            'aid' => $applicationId
                        ]);

                        $message = 'Application status updated.';
                    } else {
                        $message = 'That application does not belong to your company.';
                    }
                }
            }

            // Load applicants belonging only to this company.
            $stmt = $pdo->prepare(
                'SELECT
                    a.id,
                    a.status,
                    a.applied_at,
                    u.name AS student_name,
                    u.email,
                    s.skills,
                    s.college,
                    i.title
                 FROM applications a
                 INNER JOIN internships i
                     ON i.id = a.internship_id
                 INNER JOIN students s
                     ON s.id = a.student_id
                 INNER JOIN users u
                     ON u.id = s.user_id
                 WHERE i.company_id = :cid
                 ORDER BY a.applied_at DESC, a.id DESC'
            );

            $stmt->execute([
                'cid' => $companyId
            ]);

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $exception) {
        error_log(
            'InternTrack company applicants: ' .
            $exception->getMessage()
        );

        $error = 'Applicants could not be loaded or updated. Check the database connection and schema.';
    }
}
?>
