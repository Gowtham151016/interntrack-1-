<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_role('company');

$rows = [];
$error = '';
$companyId = 0;
$flashMessage = take_flash();
$message = '';

if (!$pdo instanceof PDO) {
    $error = $dbError ?: 'Database connection is unavailable.';
} else {
    try {
        $stmt = $pdo->prepare('SELECT id FROM companies WHERE user_id = :uid LIMIT 1');
        $stmt->execute(['uid' => (int)$_SESSION['user_id']]);
        $companyId = (int)$stmt->fetchColumn();
        if ($companyId < 1) {
            $error = 'A company profile was not found for this account.';
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['internship_id'] ?? 0);
            $stmt = $pdo->prepare("UPDATE internships SET status = CASE WHEN status = 'Open' THEN 'Closed' ELSE 'Open' END WHERE id = :id AND company_id = :cid");
            $stmt->execute(['id' => $id, 'cid' => $companyId]);
            $message = $stmt->rowCount() ? 'Internship status updated.' : 'No matching internship was found.';
        }

        if ($companyId > 0) {
            $stmt = $pdo->prepare('SELECT i.*, (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) AS applicant_count FROM internships i WHERE i.company_id = :cid ORDER BY i.created_at DESC, i.id DESC');
            $stmt->execute(['cid' => $companyId]);
            $rows = $stmt->fetchAll();
        }
    } catch (Throwable $exception) {
        error_log('InternTrack company internships: ' . $exception->getMessage());
        $error = 'Internships could not be loaded or updated. Check the database connection and schema.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Internships · InternTrack</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/../includes/galaxy_bg.php'; include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard">
    <div class="page-heading"><div><p class="eyebrow">ROLE MANAGEMENT</p><h1>My internships.</h1><p>Control which opportunities are currently accepting applications.</p></div><a class="btn primary" href="add_internship.php">Add new</a></div>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($flashMessage): ?><div class="alert <?= ($flashMessage['type'] ?? '') === 'success' ? 'success' : 'error' ?>"><?= e($flashMessage['message'] ?? '') ?></div><?php endif; ?>
    <?php if ($message): ?><div class="alert <?= str_starts_with($message, 'Internship status') ? 'success' : 'error' ?>"><?= e($message) ?></div><?php endif; ?>
    <div class="table-card"><table><thead><tr><th>Role</th><th>Location</th><th>Applicants</th><th>Status</th><th>Action</th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="5" class="empty">No internships posted yet.</td></tr><?php else: foreach ($rows as $row): ?>
        <tr><td><strong><?= e($row['title']) ?></strong><br><small><?= e($row['duration'] ?: 'Duration not set') ?></small></td><td><?= e($row['location']) ?></td><td><?= (int)$row['applicant_count'] ?></td><td><span class="status <?= ($row['status'] ?? '') === 'Open' ? 'open' : 'rejected' ?>"><?= e($row['status']) ?></span></td><td><form method="post"><input type="hidden" name="internship_id" value="<?= (int)$row['id'] ?>"><button class="btn small" type="submit"><?= ($row['status'] ?? '') === 'Open' ? 'Close' : 'Reopen' ?></button></form></td></tr>
    <?php endforeach; endif; ?>
    </tbody></table></div>
</main>
</body>
</html>
