
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

require_role('company');

$error = '';
$title = '';
$description = '';
$location = '';
$skills = '';
$duration = '';
$stipend = '';
$companyId = 0;

if (!isset($dbError)) {
    $dbError = null;
}

if (!isset($pdo) || !$pdo instanceof PDO) {
    $error = $dbError ?: 'Database connection is unavailable.';
} else {
    try {
        $stmt = $pdo->prepare(
            'SELECT id FROM companies WHERE user_id = :uid LIMIT 1'
        );

        $stmt->execute([
            'uid' => (int) $_SESSION['user_id']
        ]);

        $companyId = (int) $stmt->fetchColumn();

        if ($companyId < 1) {
            $error = 'A company profile was not found for this account.';
        }
    } catch (Throwable $exception) {
        error_log(
            'InternTrack company profile lookup: ' .
            $exception->getMessage()
        );

        $error = 'Could not load your company profile. Check the database connection.';
    }
}
?>
