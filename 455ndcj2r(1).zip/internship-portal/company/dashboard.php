<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_role('company');

$company = [];
$rolesCount = 0;
$openCount = 0;
$applicantCount = 0;
$error = '';
$flashMessage = take_flash();

if (!$pdo instanceof PDO) {
    $error = $dbError ?: 'Database connection is unavailable.';
} else {
    try {
        $stmt = $pdo->prepare('SELECT id, company_name FROM companies WHERE user_id = :uid LIMIT 1');
        $stmt->execute(['uid' => (int)$_SESSION['user_id']]);
        $company = $stmt->fetch() ?: [];

        if (!$company) {
            $error = 'A company profile was not found for this account. Please register again with a company account or contact support.';
        } else {
            $companyId = (int)$company['id'];
            $stmt = $pdo->prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'Open' THEN 1 ELSE 0 END) AS open_total FROM internships WHERE company_id = :cid");
            $stmt->execute(['cid' => $companyId]);
            $stats = $stmt->fetch() ?: [];
            $rolesCount = (int)($stats['total'] ?? 0);
            $openCount = (int)($stats['open_total'] ?? 0);

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM applications a INNER JOIN internships i ON i.id = a.internship_id WHERE i.company_id = :cid');
            $stmt->execute(['cid' => $companyId]);
            $applicantCount = (int)$stmt->fetchColumn();
        }
    } catch (Throwable $exception) {
        error_log('InternTrack company dashboard: ' . $exception->getMessage());
        $error = 'The company dashboard could not be loaded. Check the MySQL connection and database.sql schema.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Company Dashboard · InternTrack</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/../includes/galaxy_bg.php'; include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard">
    <div class="page-heading">
        <div><p class="eyebrow">HIRING WORKSPACE</p><h1><?= e($company['company_name'] ?? $_SESSION['name'] ?? 'Company') ?></h1><p>Publish opportunities and manage candidates from one dashboard.</p></div>
        <a class="btn primary" href="add_internship.php">Post an internship</a>
    </div>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($flashMessage): ?><div class="alert <?= ($flashMessage['type'] ?? '') === 'success' ? 'success' : 'error' ?>"><?= e($flashMessage['message'] ?? '') ?></div><?php endif; ?>
    <div class="stats-grid">
        <div class="stat-card"><span>Roles posted</span><strong><?= $rolesCount ?></strong></div>
        <div class="stat-card"><span>Open roles</span><strong><?= $openCount ?></strong></div>
        <div class="stat-card"><span>Total applicants</span><strong><?= $applicantCount ?></strong></div>
    </div>
    <div class="quick-grid">
        <a class="quick-card" href="add_internship.php"><h3>Create opportunity</h3><p>Publish a new internship with skills, duration and stipend.</p></a>
        <a class="quick-card" href="internships.php"><h3>Manage roles</h3><p>Review your listings and close roles when they are filled.</p></a>
        <a class="quick-card" href="applicants.php"><h3>Review applicants</h3><p>Move candidates through review, interview and selection.</p></a>
    </div>
</main>
</body>
</html>
