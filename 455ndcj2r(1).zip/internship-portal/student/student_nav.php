<?php
// Shared navigation for every student page.
$currentPage = basename($_SERVER['PHP_SELF'] ?? 'dashboard.php');
$studentName = $_SESSION['name'] ?? 'Student';
$studentInitial = strtoupper(substr(trim((string)$studentName), 0, 1));
if ($studentInitial === '') $studentInitial = 'S';

$studentLinks = [
    ['file' => 'dashboard.php', 'label' => 'Dashboard', 'icon' => '⌂'],
    ['file' => 'internships.php', 'label' => 'Internships', 'icon' => '⌕'],
    ['file' => 'applications.php', 'label' => 'My Applications', 'icon' => '▤'],
    ['file' => 'profile.php', 'label' => 'My Profile', 'icon' => '♙'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($pageTitle ?? 'InternTrack · Student', ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/student.css">
    <link rel="stylesheet" href="../css/galaxy.css">
</head>
<body>
<?php include __DIR__ . '/../includes/galaxy_bg.php'; ?>
<style>
:root {
    --it-bg:#080d1c; --it-bg2:#101932; --it-panel:#121c35;
    --it-text:#f7f9ff; --it-muted:#a8b5d1; --it-cyan:#23ead4;
    --it-blue:#4385ff; --it-purple:#a44cff; --it-pink:#ff5cb8;
    --it-border:rgba(255,255,255,.12);
    --it-gradient:linear-gradient(110deg,var(--it-cyan),var(--it-blue),var(--it-purple));
}
* { box-sizing:border-box; }
body { margin:0; background:radial-gradient(ellipse at 5% 10%,rgba(35,234,212,.06),transparent 32%),radial-gradient(ellipse at 95% 20%,rgba(164,76,255,.10),transparent 35%),var(--it-bg); color:var(--it-text); font-family:Inter,"Segoe UI",Arial,sans-serif; line-height:1.6; }
a { color:inherit; text-decoration:none; }
.it-navbar { position:sticky; top:0; z-index:1000; background:rgba(8,13,28,.88); border-bottom:1px solid var(--it-border); backdrop-filter:blur(18px); }
.it-nav-inner { width:min(1180px,92%); min-height:76px; margin:auto; display:flex; align-items:center; justify-content:space-between; gap:22px; }
.it-logo { display:inline-flex; align-items:center; gap:10px; font-size:24px; font-weight:900; letter-spacing:-1px; white-space:nowrap; }
.it-logo-icon { display:grid; place-items:center; width:38px; height:38px; border-radius:12px; color:#071326; background:var(--it-gradient); box-shadow:0 0 25px rgba(35,234,212,.18); }
.it-logo-text { background:linear-gradient(90deg,#fff,var(--it-cyan)); -webkit-background-clip:text; background-clip:text; color:transparent; }
.it-desktop-links { display:flex; align-items:center; justify-content:center; gap:5px; }
.it-nav-link { padding:10px 13px; border:1px solid transparent; border-radius:11px; color:var(--it-muted); font-size:13px; font-weight:750; transition:.2s ease; }
.it-nav-link:hover,.it-nav-link.active { color:var(--it-cyan); background:rgba(35,234,212,.07); border-color:rgba(35,234,212,.16); }
.it-nav-actions { display:flex; align-items:center; gap:10px; }
.it-user { display:flex; align-items:center; gap:9px; color:var(--it-muted); font-size:12px; }
.it-avatar { display:grid; place-items:center; width:34px; height:34px; border-radius:11px; background:var(--it-gradient); color:#071326; font-weight:900; }
.it-logout { padding:9px 12px; border:1px solid var(--it-border); border-radius:10px; color:var(--it-text); font-size:12px; font-weight:750; }
.it-logout:hover { border-color:var(--it-pink); color:#ff9dce; }
.it-menu-button { display:none; width:42px; height:42px; border:1px solid var(--it-border); border-radius:12px; background:var(--it-panel); color:var(--it-text); font-size:22px; cursor:pointer; }
.it-mobile-backdrop { display:none; position:fixed; inset:0; z-index:1100; background:rgba(0,0,0,.58); }
.it-mobile-sidebar { position:fixed; top:0; right:0; bottom:0; z-index:1101; width:min(310px,86vw); padding:24px 18px; background:#0c1429; border-left:1px solid var(--it-border); transform:translateX(105%); transition:transform .28s ease; box-shadow:-20px 0 60px rgba(0,0,0,.25); }
.it-mobile-sidebar.open { transform:translateX(0); }
.it-mobile-backdrop.open { display:block; }
.it-sidebar-top { display:flex; align-items:center; justify-content:space-between; margin-bottom:28px; }
.it-close-button { width:38px; height:38px; border:1px solid var(--it-border); border-radius:10px; color:var(--it-text); background:var(--it-panel); font-size:22px; cursor:pointer; }
.it-mobile-links { display:grid; gap:8px; }
.it-mobile-links .it-nav-link { display:block; padding:14px; font-size:14px; }
.it-mobile-bottom { margin-top:24px; padding-top:18px; border-top:1px solid var(--it-border); }
.it-mobile-bottom .it-logout { display:block; text-align:center; }
@media(max-width:900px) {
    .it-nav-inner { min-height:68px; }
    .it-desktop-links,.it-nav-actions { display:none; }
    .it-menu-button { display:block; }
}
@media(prefers-reduced-motion:reduce) {
    *,*::before,*::after { transition:none!important; animation:none!important; scroll-behavior:auto!important; }
}
</style>

<header class="it-navbar">
    <div class="it-nav-inner">
        <a class="it-logo" href="dashboard.php" aria-label="InternTrack Student Dashboard">
            <svg class="it-logo-mark" viewBox="0 0 40 40" width="38" height="38" aria-hidden="true" focusable="false"><defs><linearGradient id="itLogoGradDesk" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#23ead4"/><stop offset=".55" stop-color="#4385ff"/><stop offset="1" stop-color="#a44cff"/></linearGradient></defs><rect width="40" height="40" rx="12" fill="url(#itLogoGradDesk)"/><path d="M9.5 28.5 L16 21.5 L21.5 25.5 L30.5 13.5" fill="none" stroke="#071326" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="30.5" cy="13.5" r="2.8" fill="#071326"/></svg>
            <span class="it-logo-text">InternTrack</span>
        </a>

        <nav class="it-desktop-links" aria-label="Student navigation">
            <?php foreach ($studentLinks as $link): ?>
                <a class="it-nav-link <?= $currentPage === $link['file'] ? 'active' : '' ?>"
                   href="<?= e($link['file']) ?>">
                    <?= e($link['label']) ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="it-nav-actions">
            <span class="it-user">
                <span class="it-avatar"><?= e($studentInitial) ?></span>
                <?= e($studentName) ?>
            </span>
            <a class="it-logout" href="../logout.php">Log out ↗</a>
        </div>

        <button class="it-menu-button" type="button" id="itMenuOpen"
                aria-label="Open navigation menu" aria-controls="itMobileSidebar"
                aria-expanded="false">☰</button>
    </div>
</header>

<div class="it-mobile-backdrop" id="itMobileBackdrop"></div>
<aside class="it-mobile-sidebar" id="itMobileSidebar" aria-label="Mobile navigation">
    <div class="it-sidebar-top">
        <a class="it-logo" href="dashboard.php">
            <svg class="it-logo-mark" viewBox="0 0 40 40" width="38" height="38" aria-hidden="true" focusable="false"><defs><linearGradient id="itLogoGradMob" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#23ead4"/><stop offset=".55" stop-color="#4385ff"/><stop offset="1" stop-color="#a44cff"/></linearGradient></defs><rect width="40" height="40" rx="12" fill="url(#itLogoGradMob)"/><path d="M9.5 28.5 L16 21.5 L21.5 25.5 L30.5 13.5" fill="none" stroke="#071326" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="30.5" cy="13.5" r="2.8" fill="#071326"/></svg>
            <span class="it-logo-text">InternTrack</span>
        </a>
        <button class="it-close-button" type="button" id="itMenuClose" aria-label="Close menu">×</button>
    </div>
    <p style="color:var(--it-muted);font-size:12px;margin:0 0 14px;">STUDENT MENU</p>
    <nav class="it-mobile-links">
        <?php foreach ($studentLinks as $link): ?>
            <a class="it-nav-link <?= $currentPage === $link['file'] ? 'active' : '' ?>"
               href="<?= e($link['file']) ?>">
                <span style="display:inline-block;width:24px;color:var(--it-cyan)"><?= e($link['icon']) ?></span>
                <?= e($link['label']) ?>
            </a>
        <?php endforeach; ?>
    </nav>
    <div class="it-mobile-bottom">
        <a class="it-logout" href="../logout.php">Log out ↗</a>
    </div>
</aside>

<script>
(function () {
    const openButton = document.getElementById('itMenuOpen');
    const closeButton = document.getElementById('itMenuClose');
    const sidebar = document.getElementById('itMobileSidebar');
    const backdrop = document.getElementById('itMobileBackdrop');

    function openMenu() {
        sidebar.classList.add('open');
        backdrop.classList.add('open');
        openButton.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
    }
    function closeMenu() {
        sidebar.classList.remove('open');
        backdrop.classList.remove('open');
        openButton.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    }
    openButton.addEventListener('click', openMenu);
    closeButton.addEventListener('click', closeMenu);
    backdrop.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeMenu();
    });
})();
</script>
