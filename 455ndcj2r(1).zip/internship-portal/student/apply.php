<?php
session_start();

require_once __DIR__ . '/../config/database.php';

// Check whether the user is logged in.
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Only students can apply for internships.
if (($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../login.php');
    exit;
}

// Escape output safely.
if (!function_exists('e')) {
    function e(mixed $v): string
    {
        return htmlspecialchars(
            (string) $v,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Get the internship ID.
$internshipId = (int) (
    $_GET['internship_id']
    ?? $_POST['internship_id']
    ?? 0
);

$internship = null;
$error = '';
$success = '';

try {
    // Verify the database connection.
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new RuntimeException(
            'PDO database connection is missing.'
        );
    }

    // Fetch the selected open internship.
    $q = $pdo->prepare(
        "SELECT *
         FROM internships
         WHERE id = :id
         AND status = 'Open'
         LIMIT 1"
    );

    $q->execute([
        'id' => $internshipId
    ]);

    $internship = $q->fetch(PDO::FETCH_ASSOC) ?: null;

    // Process the application form.
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!$internship) {
            $error = 'This internship is no longer available.';
        } else {
            // Find the student's profile.
            $sq = $pdo->prepare(
                'SELECT id
                 FROM students
                 WHERE user_id = :uid
                 LIMIT 1'
            );

            $sq->execute([
                'uid' => (int) $_SESSION['user_id']
            ]);

            $studentId = (int) $sq->fetchColumn();

            if (!$studentId) {
                $error = 'Please create your student profile before applying.';
            } else {
                // Prevent duplicate applications.
                $check = $pdo->prepare(
                    'SELECT id
                     FROM applications
                     WHERE student_id = :sid
                     AND internship_id = :iid
                     LIMIT 1'
                );

                $check->execute([
                    'sid' => $studentId,
                    'iid' => $internshipId
                ]);

                if ($check->fetchColumn()) {
                    $success = 'You have already applied for this internship.';
                } else {
                    // Submit the application.
                    $insert = $pdo->prepare(
                        "INSERT INTO applications
                         (student_id, internship_id, status)
                         VALUES (:sid, :iid, 'Applied')"
                    );

                    $insert->execute([
                        'sid' => $studentId,
                        'iid' => $internshipId
                    ]);

                    $success = 'Your application has been submitted successfully.';
                }
            }
        }
    }
} catch (Throwable $ex) {
    error_log(
        'InternTrack apply: ' . $ex->getMessage()
    );

    $error = 'Application could not be submitted. Please check the database configuration and application table columns.';
}

// Load the student navigation.
require __DIR__ . '/student_nav.php';
?>


<main class="it-page">

    <section class="it-page-head">
        <div>
            <p class="it-eyebrow">Take the next step</p>

            <h1>
                Apply for an
                <span class="it-gradient">Internship</span>
            </h1>

            <p class="it-muted">
                Review the opportunity before submitting your application.
            </p>
        </div>
    </section>

    <?php if ($success): ?>

        <div class="it-alert success">
            <?= e($success) ?>
        </div>

        <a class="it-button" href="applications.php">
            View my applications →
        </a>

    <?php elseif ($error): ?>

        <div class="it-alert error">
            <?= e($error) ?>
        </div>

    <?php endif; ?>

    <?php if ($internship): ?>

        <?php
        $title = $internship['title']
            ?? $internship['role']
            ?? 'Internship opportunity';
        ?>

        <article class="it-item">

            <span class="it-pill">
                Open opportunity
            </span>

            <h2 style="margin: 14px 0 8px">
                <?= e($title) ?>
            </h2>

            <p class="it-muted">
                <?= e(
                    $internship['description']
                    ?? 'No description provided.'
                ) ?>
            </p>

            <div class="it-meta">

                <span>
                    ⌖
                    <?= e(
                        $internship['location']
                        ?? 'Location not specified'
                    ) ?>
                </span>

                <?php if (!empty($internship['stipend'])): ?>
                    <span>
                        ◈ Stipend:
                        <?= e($internship['stipend']) ?>
                    </span>
                <?php endif; ?>

                <?php if (!empty($internship['duration'])): ?>
                    <span>
                        ◷
                        <?= e($internship['duration']) ?>
                    </span>
                <?php endif; ?>

            </div>

            <?php if (!$success && !$error): ?>

                <form
                    method="post"
                    action="apply.php"
                    style="margin-top: 22px"
                >

                    <input
                        type="hidden"
                        name="internship_id"
                        value="<?= e($internshipId) ?>"
                    >

                    <button
                        class="it-button"
                        type="submit"
                    >
                        Submit application →
                    </button>

                    <a
                        class="it-button secondary"
                        href="internships.php"
                    >
                        Back to internships
                    </a>

                </form>

            <?php endif; ?>

        </article>

    <?php elseif (!$error): ?>

        <div class="it-empty">
            This internship is not available or could not be found.

            <a
                href="internships.php"
                style="color: var(--it-cyan)"
            >
                Browse open internships →
            </a>
        </div>

    <?php endif; ?>

    <footer class="it-footer">
        InternTrack · Good luck with your application.
    </footer>

</main>
