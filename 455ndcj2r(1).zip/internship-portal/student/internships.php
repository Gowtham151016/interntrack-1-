<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
if (($_SESSION['role'] ?? '') !== 'student') { header('Location: ../login.php'); exit; }
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

$search = trim($_GET['q'] ?? '');
$internships = [];
$error = '';
$flash = $_SESSION['student_flash'] ?? '';
unset($_SESSION['student_flash']);

try {
    if (!isset($pdo) || !($pdo instanceof PDO)) throw new RuntimeException('PDO connection missing.');
    // Filter in PHP so this page only relies on the known status column and SELECT *.
    $q = $pdo->query("SELECT * FROM internships WHERE status='Open' ORDER BY id DESC");
    $all = $q->fetchAll(PDO::FETCH_ASSOC);
    foreach ($all as $row) {
        $haystack = implode(' ', array_map('strval', [
            $row['title'] ?? '', $row['role'] ?? '', $row['description'] ?? '',
            $row['location'] ?? '', $row['skills'] ?? '', $row['company_name'] ?? ''
        ]));
        if ($search === '' || stripos($haystack, $search) !== false) $internships[] = $row;
    }
} catch (Throwable $ex) {
    error_log('InternTrack internships: '.$ex->getMessage());
    $error = 'Internships could not be loaded. Please check the database connection and internship table.';
}
require __DIR__ . '/student_nav.php';
?>
<main class="it-page">
    <?php if ($flash): ?><div class="it-alert success"><?= e($flash) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="it-alert error"><?= e($error) ?></div><?php endif; ?>
    <section class="it-page-head">
        <div><p class="it-eyebrow">Discover opportunities</p><h1>Explore <span class="it-gradient">Internships</span></h1>
        <p class="it-muted">Search open roles and apply to opportunities that interest you.</p></div>
    </section>

    <form class="it-search" method="get" action="internships.php">
        <input type="search" name="q" value="<?= e($search) ?>" placeholder="Search title, skills, or location..." aria-label="Search internships">
        <button class="it-button" type="submit">Search ↗</button>
        <?php if ($search !== ''): ?><a class="it-button secondary" href="internships.php">Clear</a><?php endif; ?>
    </form>

    <p class="it-muted" style="font-size:12px;margin:0 0 15px"><?= count($internships) ?> open opportunity/opportunities found</p>

    <?php if (!$internships): ?>
        <div class="it-empty">No open internships matched your search. Try another keyword or check back later.</div>
    <?php else: ?>
        <section class="it-list">
        <?php foreach ($internships as $internship): ?>
            <?php
                $title = $internship['title'] ?? $internship['role'] ?? 'Internship opportunity';
                $company = $internship['company_name'] ?? $internship['company'] ?? '';
                $location = $internship['location'] ?? 'Location not specified';
                $description = $internship['description'] ?? 'No description has been added yet.';
                $stipend = $internship['stipend'] ?? $internship['salary'] ?? '';
                $duration = $internship['duration'] ?? '';
            ?>
            <article class="it-item it-reveal">
                <div class="it-item-top">
                    <div><h3><?= e($title) ?></h3>
                    <p style="margin:0 0 13px"><?= e($company ?: 'Company opportunity') ?></p></div>
                    <span class="it-pill">Open</span>
                </div>
                <p><?= e(mb_strimwidth((string)$description, 0, 260, '…')) ?></p>
                <div class="it-meta">
                    <span>⌖ <?= e($location) ?></span>
                    <?php if ($stipend !== ''): ?><span>◈ Stipend: <?= e($stipend) ?></span><?php endif; ?>
                    <?php if ($duration !== ''): ?><span>◷ <?= e($duration) ?></span><?php endif; ?>
                </div>
                <div class="it-actions">
                    <a class="it-button" href="apply.php?internship_id=<?= (int)($internship['id'] ?? 0) ?>">View / Apply →</a>
                </div>
            </article>
        <?php endforeach; ?>
        </section>
    <?php endif; ?>
    <footer class="it-footer">InternTrack · Explore, apply, and grow.</footer>
</main>
