<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
if (($_SESSION['role'] ?? '') !== 'student') { header('Location: ../login.php'); exit; }
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

$userId = (int)$_SESSION['user_id'];
$student = [];
$error = '';
$success = '';
$editableFields = [
    'name' => 'Full name',
    'phone' => 'Phone',
    'college' => 'College / University',
    'degree' => 'Degree',
    'skills' => 'Skills',
    'bio' => 'About me',
    'resume' => 'Resume link'
];

try {
    if (!isset($pdo) || !($pdo instanceof PDO)) throw new RuntimeException('PDO connection missing.');
    $q = $pdo->prepare('SELECT * FROM students WHERE user_id=:uid LIMIT 1');
    $q->execute(['uid' => $userId]);
    $student = $q->fetch(PDO::FETCH_ASSOC) ?: [];

    if (!$student) {
        $error = 'A student profile was not found for this account. Your registration process may need to create the students record.';
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Only update fields that actually exist in the students table.
        $allowed = array_intersect(array_keys($editableFields), array_keys($student));
        $updates = [];
        $params = ['id' => (int)$student['id'], 'uid' => $userId];
        foreach ($allowed as $field) {
            if ($field === 'resume') continue; // resume upload/link may be handled separately by your project.
            $value = trim((string)($_POST[$field] ?? ''));
            $updates[] = "`$field` = :$field";
            $params[$field] = $value;
        }
        if ($updates) {
            $sql = 'UPDATE students SET '.implode(', ', $updates).' WHERE id=:id AND user_id=:uid';
            $update = $pdo->prepare($sql);
            $update->execute($params);
            $success = 'Your profile has been updated.';
            $q = $pdo->prepare('SELECT * FROM students WHERE user_id=:uid LIMIT 1');
            $q->execute(['uid' => $userId]);
            $student = $q->fetch(PDO::FETCH_ASSOC) ?: $student;
            if (!empty($student['name'])) $_SESSION['name'] = $student['name'];
        } else {
            $error = 'No editable profile fields were found in the students table.';
        }
    }
} catch (Throwable $ex) {
    error_log('InternTrack profile: '.$ex->getMessage());
    $error = 'Profile could not be loaded or saved. Please check the students table columns.';
}
require __DIR__ . '/student_nav.php';
?>
<main class="it-page">
    <section class="it-page-head">
        <div><p class="it-eyebrow">Your information</p><h1>My <span class="it-gradient">Profile</span></h1>
        <p class="it-muted">Keep your details up to date so companies can learn about you.</p></div>
    </section>

    <?php if ($success): ?><div class="it-alert success"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="it-alert error"><?= e($error) ?></div><?php endif; ?>

    <?php if ($student): ?>
        <form class="it-card" method="post" action="profile.php">
            <div class="it-form-grid">
                <?php foreach ($editableFields as $field => $label): ?>
                    <?php if (!array_key_exists($field, $student) || $field === 'resume') continue; ?>
                    <div class="it-field">
                        <label for="<?= e($field) ?>"><?= e($label) ?></label>
                        <?php if ($field === 'bio' || $field === 'skills'): ?>
                            <textarea id="<?= e($field) ?>" name="<?= e($field) ?>"><?= e($student[$field] ?? '') ?></textarea>
                        <?php else: ?>
                            <input id="<?= e($field) ?>" name="<?= e($field) ?>"
                                   value="<?= e($student[$field] ?? '') ?>"
                                   <?= $field === 'name' ? 'required' : '' ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <div class="it-field">
                    <label for="account_email">Account email</label>
                    <input id="account_email" value="<?= e($_SESSION['email'] ?? 'Managed by your account') ?>" disabled>
                </div>
            </div>
            <button class="it-button" type="submit">Save profile changes →</button>
        </form>
    <?php endif; ?>
    <footer class="it-footer">InternTrack · Make your skills visible.</footer>
</main>
