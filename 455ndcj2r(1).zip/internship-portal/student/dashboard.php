<?php
session_start();

require_once __DIR__ . '/../config/database.php';

// Check whether the user is logged in.
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Allow only students to access this page.
if (($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../login.php');
    exit;
}

// Escape output safely and fix the P1132 warning.
if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Initialize dashboard variables.
$name = $_SESSION['name'] ?? 'Student';
$student = [];

$total = 0;
$review = 0;
$shortlisted = 0;
$selected = 0;
$openInternships = 0;

$error = '';

try {
    // Verify database connection.
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new RuntimeException(
            'PDO database connection is missing.'
        );
    }

    // Fetch student profile.
    $q = $pdo->prepare(
        'SELECT *
         FROM students
         WHERE user_id = :uid
         LIMIT 1'
    );

    $q->execute([
        'uid' => (int) $_SESSION['user_id']
    ]);

    $student = $q->fetch(PDO::FETCH_ASSOC) ?: [];

    if (!empty($student['name'])) {
        $name = $student['name'];
    }

    $studentId = (int) ($student['id'] ?? 0);

    // Fetch application statistics.
    if ($studentId > 0) {
        $q = $pdo->prepare(
            "SELECT
                COUNT(*) AS total,
                SUM(
                    CASE
                        WHEN status = 'Under Review'
                        THEN 1 ELSE 0
                    END
                ) AS review_count,
                SUM(
                    CASE
                        WHEN status = 'Shortlisted'
                        THEN 1 ELSE 0
                    END
                ) AS shortlisted_count,
                SUM(
                    CASE
                        WHEN status = 'Selected'
                        THEN 1 ELSE 0
                    END
                ) AS selected_count
             FROM applications
             WHERE student_id = :sid"
        );

        $q->execute([
            'sid' => $studentId
        ]);

        $stats = $q->fetch(PDO::FETCH_ASSOC) ?: [];

        $total = (int) ($stats['total'] ?? 0);
        $review = (int) ($stats['review_count'] ?? 0);
        $shortlisted = (int) ($stats['shortlisted_count'] ?? 0);
        $selected = (int) ($stats['selected_count'] ?? 0);
    }

    // Count open internships.
    $openInternships = (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM internships
             WHERE status = 'Open'"
        )
        ->fetchColumn();

} catch (Throwable $ex) {
    error_log(
        'InternTrack dashboard: ' . $ex->getMessage()
    );

    $error = 'We could not load all dashboard information. Please check your database connection and table structure.';
}

// Load student navigation.
require __DIR__ . '/student_nav.php';
?>


<main class="it-page dash-page">

    <?php if ($error): ?>
        <div class="it-alert error">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <section class="it-page-head it-reveal">
        <div>
            <p class="it-eyebrow">Student space</p>

            <h1>
                Welcome back,
                <span class="it-gradient">
                    <?= e(explode(' ', trim($name))[0] ?: 'Student') ?>.
                </span>
            </h1>

            <p class="it-muted">
                Your opportunities, applications, and career progress
                in one place.
            </p>
        </div>

        <a class="it-button" href="internships.php">
            Explore internships →
        </a>
    </section>

    <section class="it-stat-grid">

        <article class="it-stat it-reveal">
            <span>Total applications</span>
            <strong><?= $total ?></strong>
        </article>

        <article class="it-stat it-reveal">
            <span>Under review</span>
            <strong><?= $review ?></strong>
        </article>

        <article class="it-stat it-reveal">
            <span>Shortlisted</span>
            <strong><?= $shortlisted ?></strong>
        </article>

        <article class="it-stat it-reveal">
            <span>Open internships</span>
            <strong><?= $openInternships ?></strong>
        </article>

    </section>

    <section class="dash-section-head">
        <p class="it-eyebrow">Keep moving forward</p>
        <h2>Your next step</h2>
    </section>

    <section class="it-grid">

        <article class="it-card it-reveal">
            <p class="it-eyebrow">01 / Discover</p>

            <h3>Find an internship</h3>

            <p class="it-muted">
                Explore currently open opportunities and find a role
                that matches your interests.
            </p>

            <a class="it-button" href="internships.php">
                Browse roles →
            </a>
        </article>

        <article class="it-card it-reveal">
            <p class="it-eyebrow">02 / Track</p>

            <h3>Application status</h3>

            <p class="it-muted">
                See the latest status of the applications you have
                submitted.
            </p>

            <a
                class="it-button secondary"
                href="applications.php"
            >
                My applications →
            </a>
        </article>

        <article class="it-card it-reveal">
            <p class="it-eyebrow">03 / Prepare</p>

            <h3>Update your profile</h3>

            <p class="it-muted">
                Keep your contact details, college, skills, and other
                information up to date.
            </p>

            <a
                class="it-button secondary"
                href="profile.php"
            >
                Edit profile →
            </a>
        </article>

    </section>

    <footer class="it-footer">
        InternTrack · Your next opportunity starts here.
    </footer>

</main>
