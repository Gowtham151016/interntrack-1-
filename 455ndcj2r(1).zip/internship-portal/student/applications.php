<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
if (($_SESSION['role'] ?? '') !== 'student') { header('Location: ../login.php'); exit; }
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

$applications = [];
$error = '';
try {
    if (!isset($pdo) || !($pdo instanceof PDO)) throw new RuntimeException('PDO connection missing.');
    $q = $pdo->prepare('SELECT id FROM students WHERE user_id=:uid LIMIT 1');
    $q->execute(['uid' => (int)$_SESSION['user_id']]);
    $studentId = (int)$q->fetchColumn();
    if ($studentId > 0) {
        // Fetch applications and internship rows separately to avoid depending on company-table column names.
        $q = $pdo->prepare('SELECT * FROM applications WHERE student_id=:sid ORDER BY id DESC');
        $q->execute(['sid' => $studentId]);
        $rows = $q->fetchAll(PDO::FETCH_ASSOC);
        $internshipIds = array_values(array_unique(array_filter(array_map(
            fn($r) => (int)($r['internship_id'] ?? 0), $rows
        ))));
        $internshipMap = [];
        if ($internshipIds) {
            $placeholders = implode(',', array_fill(0, count($internshipIds), '?'));
            $iq = $pdo->prepare("SELECT * FROM internships WHERE id IN ($placeholders)");
            $iq->execute($internshipIds);
            foreach ($iq->fetchAll(PDO::FETCH_ASSOC) as $ir) $internshipMap[(int)$ir['id']] = $ir;
        }
        foreach ($rows as $row) {
            $ir = $internshipMap[(int)($row['internship_id'] ?? 0)] ?? [];
            $row['_internship_title'] = $ir['title'] ?? $ir['role'] ?? 'Internship opportunity';
            $row['_company'] = $ir['company_name'] ?? $ir['company'] ?? '';
            $applications[] = $row;
        }
    }
} catch (Throwable $ex) {
    error_log('InternTrack applications: '.$ex->getMessage());
    $error = 'Your applications could not be loaded. Please check your database schema.';
}
require __DIR__ . '/student_nav.php';
?>
<main class="it-page">
    <?php if ($error): ?><div class="it-alert error"><?= e($error) ?></div><?php endif; ?>
    <section class="it-page-head">
        <div><p class="it-eyebrow">Your progress</p><h1>My <span class="it-gradient">Applications</span></h1>
        <p class="it-muted">Follow the progress of the internships you have applied for.</p></div>
        <a class="it-button" href="internships.php">Find internships →</a>
    </section>

    <?php if (!$applications): ?>
        <div class="it-empty">You have not applied for an internship yet.<br><a style="display:inline-block;margin-top:10px;color:var(--it-cyan)" href="internships.php">Explore open internships →</a></div>
    <?php else: ?>
        <section class="it-list">
            <?php foreach ($applications as $application): ?>
                <?php $status = $application['status'] ?? 'Applied'; ?>
                <article class="it-item it-reveal">
                    <div class="it-item-top">
                        <div>
                            <h3><?= e($application['_internship_title']) ?></h3>
                            <?php if ($application['_company'] !== ''): ?><p style="margin:0"><?= e($application['_company']) ?></p><?php endif; ?>
                        </div>
                        <span class="it-pill"><?= e($status) ?></span>
                    </div>
                    <div class="it-meta" style="margin-top:16px">
                        <span>Application #<?= (int)($application['id'] ?? 0) ?></span>
                        <?php if (!empty($application['applied_at'])): ?><span>Applied: <?= e($application['applied_at']) ?></span><?php endif; ?>
                        <?php if (!empty($application['created_at'])): ?><span>Submitted: <?= e($application['created_at']) ?></span><?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>
    <footer class="it-footer">InternTrack · Every application is a step forward.</footer>
</main>
