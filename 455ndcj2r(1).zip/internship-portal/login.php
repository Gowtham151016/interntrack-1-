<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/config/database.php";

/*
|--------------------------------------------------------------------------
| Redirect already logged-in users
|--------------------------------------------------------------------------
*/
if (isset($_SESSION["user_id"])) {
    $role = $_SESSION["role"] ?? "";

    if ($role === "student") {
        header("Location: student/dashboard.php");
    } elseif ($role === "company") {
        header("Location: company/dashboard.php");
    } elseif ($role === "admin") {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: index.php");
    }

    exit;
}

/*
|--------------------------------------------------------------------------
| Form defaults
|--------------------------------------------------------------------------
*/
$error = "";
$email = "";

/*
|--------------------------------------------------------------------------
| Process login form
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim((string) ($_POST["email"] ?? ""));
    $password = (string) ($_POST["password"] ?? "");

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password === "") {
        $error = "Please enter your password.";
    } else {
        try {
            // Ensure the database connection is a valid PDO object.
            if (!isset($pdo) || !($pdo instanceof PDO)) {
                throw new RuntimeException("PDO database connection is unavailable.");
            }

            $stmt = $pdo->prepare(
                "SELECT id, name, email, password, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1"
            );

            if (!($stmt instanceof PDOStatement)) {
                throw new RuntimeException("Unable to prepare the login query.");
            }

            $stmt->execute(["email" => $email]);

            // fetch() may return false when no matching user exists.
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (
                is_array($user) &&
                isset(
                    $user["id"],
                    $user["name"],
                    $user["email"],
                    $user["password"],
                    $user["role"]
                ) &&
                password_verify($password, (string) $user["password"])
            ) {
                $allowedRoles = ["student", "company", "admin"];
                $userRole = (string) $user["role"];

                if (!in_array($userRole, $allowedRoles, true)) {
                    $error = "Your account role is not recognized.";
                } else {
                    // Prevent session fixation after successful authentication.
                    session_regenerate_id(true);

                    $_SESSION["user_id"] = $user["id"];
                    $_SESSION["name"] = $user["name"];
                    $_SESSION["email"] = $user["email"];
                    $_SESSION["role"] = $userRole;

                    // Remember the email only if the user selected the checkbox.
                    if (isset($_POST["remember_email"]) && $_POST["remember_email"] === "1") {
                        setcookie("remember_email", $email, [
                            "expires" => time() + (30 * 24 * 60 * 60),
                            "path" => "/",
                            "secure" => !empty($_SERVER["HTTPS"]) &&
                                $_SERVER["HTTPS"] !== "off",
                            "httponly" => true,
                            "samesite" => "Lax",
                        ]);
                    } else {
                        setcookie("remember_email", "", [
                            "expires" => time() - 3600,
                            "path" => "/",
                            "secure" => !empty($_SERVER["HTTPS"]) &&
                                $_SERVER["HTTPS"] !== "off",
                            "httponly" => true,
                            "samesite" => "Lax",
                        ]);
                    }

                    if ($userRole === "student") {
                        header("Location: student/dashboard.php");
                    } elseif ($userRole === "company") {
                        header("Location: company/dashboard.php");
                    } else {
                        header("Location: admin/dashboard.php");
                    }

                    exit;
                }
            } else {
                $error = "Incorrect email or password.";
            }
        } catch (Throwable $exception) {
            // Keep database details out of the public error message.
            error_log("InternTrack login error: " . $exception->getMessage());
            $error = "Unable to sign in right now. Please try again.";
        }
    }
}

// Restore the saved email, if one exists and the form has not been submitted.
if ($_SERVER["REQUEST_METHOD"] !== "POST" && isset($_COOKIE["remember_email"])) {
    $savedEmail = (string) $_COOKIE["remember_email"];

    if (filter_var($savedEmail, FILTER_VALIDATE_EMAIL)) {
        $email = $savedEmail;
    }
}

function login_escape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | InternTrack</title>
    <link rel="icon" type="image/jpeg" href="assets/logo.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/galaxy.css">

    <style>
        :root {
            --bg: #070910;
            --panel: #101421;
            --border: rgba(157, 174, 255, .15);
            --text: #f5f7ff;
            --muted: #939bb4;
            --blue: #5b8cff;
            --cyan: #47e7ff;
            --purple: #a66bff;
        }

        * {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
            scroll-behavior: smooth;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Inter, sans-serif;
            color: var(--text);
            background: var(--bg);
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        button,
        input {
            font: inherit;
        }

        .background-grid {
            position: fixed;
            inset: 0;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(108, 139, 255, .045) 1px, transparent 1px),
                linear-gradient(90deg, rgba(108, 139, 255, .045) 1px, transparent 1px);
            background-size: 48px 48px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
            z-index: -2;
        }

        .glow {
            position: fixed;
            width: 360px;
            height: 360px;
            border-radius: 50%;
            filter: blur(100px);
            opacity: .22;
            pointer-events: none;
            z-index: -1;
            animation: glowMove 10s ease-in-out infinite alternate;
        }

        .glow.one {
            background: #4b57ff;
            top: -150px;
            left: -100px;
        }

        .glow.two {
            background: #9b35ff;
            bottom: -170px;
            right: -100px;
            animation-delay: -4s;
        }

        @keyframes glowMove {
            from {
                transform: translate(0, 0) scale(1);
            }

            to {
                transform: translate(50px, 35px) scale(1.18);
            }
        }

        nav {
            width: min(1120px, 92%);
            margin: 0 auto;
            padding: 24px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 11px;
            font-size: 21px;
            font-weight: 800;
            letter-spacing: -.8px;
        }

        .logo {
            width: 42px;
            height: 42px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            background: linear-gradient(135deg, #527cff, #a35bff);
            border: 2px solid var(--cyan);
            box-shadow: 0 0 22px rgba(71, 231, 255, .25);
            font-size: 16px;
            font-weight: 800;
            transition: transform .3s, box-shadow .3s;
        }

        .brand:hover .logo {
            transform: rotate(-8deg) scale(1.08);
            box-shadow: 0 0 30px rgba(71, 231, 255, .45);
        }

        .gradient-text {
            background: linear-gradient(100deg, var(--blue), var(--cyan), var(--purple));
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            animation: gradientMove 4s linear infinite;
        }

        @keyframes gradientMove {
            to {
                background-position: 200% center;
            }
        }

        .nav-note {
            color: var(--muted);
            font-size: 13px;
        }

        .nav-note a,
        .switch-text a {
            color: var(--cyan);
            font-weight: 700;
            transition: color .25s;
        }

        .nav-note a:hover,
        .switch-text a:hover {
            color: #fff;
        }

        main {
            flex: 1;
            display: grid;
            place-items: center;
            padding: 25px 18px 55px;
        }

        .auth-layout {
            width: min(960px, 100%);
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: center;
            gap: 55px;
            animation: appear .75s ease both;
        }

        @keyframes appear {
            from {
                opacity: 0;
                transform: translateY(22px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .intro {
            padding: 15px 0;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 9px 13px;
            border: 1px solid var(--border);
            background: rgba(24, 31, 54, .65);
            border-radius: 30px;
            color: #b9c9ff;
            font-size: 11px;
            letter-spacing: 1.2px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .eyebrow span {
            width: 7px;
            height: 7px;
            background: var(--cyan);
            border-radius: 50%;
            box-shadow: 0 0 12px var(--cyan);
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            50% {
                opacity: .4;
                transform: scale(.75);
            }
        }

        h1 {
            margin: 25px 0 17px;
            font-size: clamp(34px, 4vw, 49px);
            line-height: 1.12;
            letter-spacing: -2px;
        }

        .intro > p {
            max-width: 390px;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.9;
        }

        .benefits {
            display: grid;
            gap: 17px;
            margin-top: 30px;
        }

        .benefit {
            display: flex;
            gap: 13px;
            align-items: center;
            color: #d9def2;
            font-size: 13px;
        }

        .benefit-icon {
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            flex-shrink: 0;
            border-radius: 11px;
            background: rgba(91, 140, 255, .12);
            border: 1px solid rgba(91, 140, 255, .2);
            color: var(--cyan);
            transition: transform .25s, background .25s, box-shadow .25s;
        }

        .benefit:hover .benefit-icon {
            transform: translateY(-3px) rotate(6deg);
            background: rgba(71, 231, 255, .13);
            box-shadow: 0 0 18px rgba(71, 231, 255, .15);
        }

        .auth-card {
            position: relative;
            padding: 34px;
            background: linear-gradient(145deg, rgba(20, 25, 43, .97), rgba(11, 14, 25, .98));
            border: 1px solid var(--border);
            border-radius: 24px;
            box-shadow: 0 25px 90px rgba(0, 0, 0, .35);
            overflow: hidden;
            backdrop-filter: blur(16px);
        }

        .auth-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 15%;
            width: 70%;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--cyan), var(--purple), transparent);
        }

        .card-icon {
            width: 49px;
            height: 49px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(94, 143, 255, .25);
            background: rgba(91, 140, 255, .12);
            border-radius: 15px;
            font-size: 23px;
            margin-bottom: 20px;
            transition: transform .3s, box-shadow .3s;
        }

        .card-icon:hover {
            transform: rotate(10deg) scale(1.07);
            box-shadow: 0 0 22px rgba(71, 231, 255, .2);
        }

        .auth-card h2 {
            margin: 0 0 9px;
            font-size: 25px;
            letter-spacing: -.7px;
        }

        .subtext {
            color: var(--muted);
            font-size: 12px;
            line-height: 1.7;
            margin: 0 0 25px;
        }

        .alert {
            padding: 12px 14px;
            border: 1px solid rgba(255, 100, 120, .28);
            background: rgba(255, 70, 100, .08);
            color: #ff9eae;
            border-radius: 10px;
            font-size: 12px;
            line-height: 1.6;
            margin-bottom: 18px;
        }

        .field {
            margin-bottom: 19px;
        }

        label {
            display: block;
            color: #dce2f8;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 9px;
        }

        .input-wrap {
            position: relative;
        }

        input[type="email"],
        input[type="password"],
        input[type="text"] {
            width: 100%;
            padding: 14px 15px;
            color: var(--text);
            background: rgba(6, 9, 18, .75);
            border: 1px solid rgba(151, 165, 220, .17);
            border-radius: 11px;
            outline: none;
            font-size: 13px;
            transition: border-color .25s, box-shadow .25s, background .25s;
        }

        input::placeholder {
            color: #69718a;
        }

        input:focus {
            border-color: var(--blue);
            background: rgba(13, 19, 36, .95);
            box-shadow: 0 0 0 4px rgba(91, 140, 255, .10);
        }

        .password-input {
            padding-right: 73px !important;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            border: 0;
            background: transparent;
            color: var(--cyan);
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            padding: 8px 2px;
            transition: color .2s;
        }

        .toggle-password:hover {
            color: white;
        }

        .toggle-password:focus-visible,
        .primary-btn:focus-visible,
        a:focus-visible {
            outline: 2px solid var(--cyan);
            outline-offset: 4px;
        }

        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin: 2px 0 22px;
            color: var(--muted);
            font-size: 11px;
        }

        .remember {
            display: flex;
            gap: 7px;
            align-items: center;
            margin: 0;
            color: var(--muted);
            font-weight: 400;
            cursor: pointer;
        }

        .remember input {
            width: 14px;
            height: 14px;
            margin: 0;
            accent-color: var(--blue);
        }

        .primary-btn {
            width: 100%;
            padding: 15px;
            border: 0;
            border-radius: 11px;
            background: linear-gradient(100deg, #4f7cff, #8758ff);
            color: white;
            font-size: 13px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 9px 28px rgba(94, 104, 255, .23);
            transition: transform .25s, box-shadow .25s, filter .25s;
        }

        .primary-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 13px 34px rgba(94, 104, 255, .38);
            filter: brightness(1.08);
        }

        .primary-btn:active {
            transform: translateY(0);
        }

        .switch-text {
            text-align: center;
            margin: 22px 0 0;
            color: var(--muted);
            font-size: 12px;
        }

        footer {
            padding: 18px;
            text-align: center;
            color: #68718a;
            font-size: 11px;
        }

        @media (max-width: 760px) {
            .auth-layout {
                grid-template-columns: 1fr;
                gap: 25px;
                max-width: 440px;
            }

            .intro {
                text-align: center;
                padding: 0;
            }

            .intro > p {
                margin: 0 auto;
            }

            .benefits {
                display: none;
            }

            h1 {
                font-size: 36px;
                margin: 18px 0 12px;
            }

            .auth-card {
                padding: 27px 23px;
            }

            nav {
                padding: 18px 0;
            }

            .nav-note {
                font-size: 11px;
                text-align: right;
            }
        }

        @media (max-width: 380px) {
            .brand {
                font-size: 18px;
            }

            .logo {
                width: 36px;
                height: 36px;
            }

            .auth-card {
                padding: 23px 18px;
            }

            .form-options {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
</head>

<body>
    <?php
    $galaxyBackground = __DIR__ . "/includes/galaxy_bg.php";

    if (is_file($galaxyBackground)) {
        include $galaxyBackground;
    }
    ?>

    <div class="background-grid" aria-hidden="true"></div>
    <div class="glow one" aria-hidden="true"></div>
    <div class="glow two" aria-hidden="true"></div>

    <nav>
        <a class="brand" href="index.php" aria-label="InternTrack home">
            <span class="logo" aria-hidden="true">IT</span>
            <span>Intern<span class="gradient-text">Track</span></span>
        </a>

        <div class="nav-note">
            New here?
            <a href="register.php">Create account ↗</a>
        </div>
    </nav>

    <main>
        <div class="auth-layout">
            <section class="intro">
                <div class="eyebrow">
                    <span aria-hidden="true"></span>
                    Your next chapter starts here
                </div>

                <h1>
                    Welcome back.<br>
                    Let's build your <span class="gradient-text">future.</span>
                </h1>

                <p>
                    Sign in to discover opportunities, manage your applications,
                    and take the next step in your career journey.
                </p>

                <div class="benefits">
                    <div class="benefit">
                        <span class="benefit-icon" aria-hidden="true">✦</span>
                        <span>Discover internship opportunities</span>
                    </div>

                    <div class="benefit">
                        <span class="benefit-icon" aria-hidden="true">↗</span>
                        <span>Track your application progress</span>
                    </div>

                    <div class="benefit">
                        <span class="benefit-icon" aria-hidden="true">⌘</span>
                        <span>Build your professional future</span>
                    </div>
                </div>
            </section>

            <section class="auth-card" aria-labelledby="login-heading">
                <div class="card-icon" aria-hidden="true">✦</div>

                <h2 id="login-heading">Sign in</h2>
                <p class="subtext">Enter your account details to continue.</p>

                <?php if ($error !== ""): ?>
                    <div class="alert" role="alert">
                        <?= login_escape($error) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <div class="field">
                        <label for="email">Email address</label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="you@example.com"
                            value="<?= login_escape($email) ?>"
                            autocomplete="email"
                            maxlength="254"
                            required
                        >
                    </div>

                    <div class="field">
                        <label for="password">Password</label>

                        <div class="input-wrap">
                            <input
                                class="password-input"
                                type="password"
                                id="password"
                                name="password"
                                placeholder="Enter your password"
                                autocomplete="current-password"
                                required
                            >

                            <button
                                class="toggle-password"
                                type="button"
                                data-target="password"
                                aria-controls="password"
                                aria-pressed="false"
                            >Show</button>
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="remember" for="remember_email">
                            <input
                                type="checkbox"
                                id="remember_email"
                                name="remember_email"
                                value="1"
                                <?= isset($_COOKIE["remember_email"]) &&
                                    filter_var((string) $_COOKIE["remember_email"], FILTER_VALIDATE_EMAIL) &&
                                    hash_equals((string) $_COOKIE["remember_email"], $email)
                                    ? "checked"
                                    : "" ?>
                            >
                            Remember email
                        </label>

                        <span>Secure sign in</span>
                    </div>

                    <button class="primary-btn" type="submit">
                        Sign In &nbsp; →
                    </button>
                </form>

                <p class="switch-text">
                    Don't have an account?
                    <a href="register.php">Create one</a>
                </p>
            </section>
        </div>
    </main>

    <footer>
        © <?= date("Y") ?> InternTrack · Your career journey starts here.
    </footer>

    <script>
        document.querySelectorAll(".toggle-password").forEach(function (button) {
            button.addEventListener("click", function () {
                const input = document.getElementById(button.dataset.target);

                if (!input) {
                    return;
                }

                const showing = input.type === "text";

                input.type = showing ? "password" : "text";
                button.textContent = showing ? "Show" : "Hide";
                button.setAttribute("aria-pressed", String(!showing));
            });
        });
    </script>
</body>
</html>
