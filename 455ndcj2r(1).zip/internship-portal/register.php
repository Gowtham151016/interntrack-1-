<?php


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/database.php';

/*
|--------------------------------------------------------------------------
| Redirect users who are already logged in
|--------------------------------------------------------------------------
*/
if (!empty($_SESSION['user_id'])) {
    $role = strtolower((string) ($_SESSION['role'] ?? ''));

    if ($role === 'student') {
        header('Location: student/dashboard.php');
    } elseif ($role === 'company') {
        header('Location: company/dashboard.php');
    } elseif ($role === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: index.php');
    }

    exit;
}

/*
|--------------------------------------------------------------------------
| Initialise form values
|--------------------------------------------------------------------------
*/
$error = '';
$success = '';
$name = '';
$email = '';
$companyName = '';
$role = 'student';

/*
|--------------------------------------------------------------------------
| Escape output safely
|--------------------------------------------------------------------------
| The mixed type declaration fixes Intelephense warning P1132.
*/
if (!function_exists('register_escape')) {
    function register_escape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Process registration
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $companyName = trim((string) ($_POST['company_name'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
    $role = strtolower(trim((string) ($_POST['role'] ?? 'student')));

    if ($name === '' || $email === '' || $password === '' || $confirmPassword === '') {
        $error = 'Please complete all required fields.';
    } elseif (mb_strlen($name) > 100) {
        $error = 'Your name must be 100 characters or fewer.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (mb_strlen($email) > 254) {
        $error = 'Your email address is too long.';
    } elseif (strlen($password) < 8) {
        $error = 'Your password must contain at least 8 characters.';
    } elseif (strlen($password) > 4096) {
        $error = 'Your password is too long.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Your passwords do not match.';
    } elseif (!in_array($role, ['student', 'company'], true)) {
        $error = 'Please select Student or Company.';
    } elseif ($role === 'company' && $companyName === '') {
        $error = 'Please enter your company name.';
    } elseif ($role === 'company' && mb_strlen($companyName) > 150) {
        $error = 'Your company name must be 150 characters or fewer.';
    } else {
        /*
         * Do not attempt database operations if the PDO connection failed.
         */
        $db = (isset($pdo) && $pdo instanceof PDO) ? $pdo : null;

        if ($db === null) {
            error_log('InternPro registration: PDO connection unavailable.');
            $error = 'Registration is temporarily unavailable. Please try again later.';
        } else {
            $transactionStarted = false;

            try {
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

                $db->beginTransaction();
                $transactionStarted = true;

                /*
                 * Check for an existing account.
                 */
                $check = $db->prepare(
                    'SELECT id FROM users WHERE email = :email LIMIT 1'
                );

                $check->execute(['email' => $email]);

                if ($check->fetch()) {
                    $db->rollBack();
                    $transactionStarted = false;
                    $error = 'This email is already registered. Please log in.';
                } else {
                    /*
                     * Create the user account.
                     */
                    $hashedPassword = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    if ($hashedPassword === false) {
                        throw new RuntimeException('Password hashing failed.');
                    }

                    $insertUser = $db->prepare(
                        'INSERT INTO users (name, email, password, role)
                         VALUES (:name, :email, :password, :role)'
                    );

                    $insertUser->execute([
                        'name' => $name,
                        'email' => $email,
                        'password' => $hashedPassword,
                        'role' => $role
                    ]);

                    $userId = (int) $db->lastInsertId();

                    /*
                     * Create the matching student or company record.
                     */
                    if ($role === 'student') {
                        $insertProfile = $db->prepare(
                            'INSERT INTO students (user_id)
                             VALUES (:user_id)'
                        );

                        $insertProfile->execute([
                            'user_id' => $userId
                        ]);
                    } else {
                        $insertProfile = $db->prepare(
                            'INSERT INTO companies (user_id, company_name)
                             VALUES (:user_id, :company_name)'
                        );

                        $insertProfile->execute([
                            'user_id' => $userId,
                            'company_name' => $companyName
                        ]);
                    }

                    $db->commit();
                    $transactionStarted = false;

                    /*
                     * Registration succeeds; preserve the existing
                     * login flow rather than automatically signing in.
                     */
                    header('Location: login.php?registered=1');
                    exit;
                }
            } catch (Throwable $exception) {
                if ($transactionStarted && $db->inTransaction()) {
                    try {
                        $db->rollBack();
                    } catch (Throwable $rollbackException) {
                        error_log(
                            'InternPro registration rollback error: '
                            . $rollbackException->getMessage()
                        );
                    }
                }

                error_log(
                    'InternPro registration error: '
                    . $exception->getMessage()
                );

                $error = 'We could not create your account. Please check your details and try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#071e3d">
    <meta name="description" content="Create your InternPro account and start your internship journey.">

    <title>Create Account | InternPro</title>

    <link rel="icon" type="image/jpeg" href="assets/logo.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --navy: #071e3d;
            --navy-light: #0d3b66;
            --primary: #00b4d8;
            --primary-dark: #0077b6;
            --bright-blue: #38bdf8;
            --white: #ffffff;
            --text: #e2e8f0;
            --muted: #94a3b8;
            --border: rgba(255,255,255,.13);
            --glass: rgba(255,255,255,.065);
            --success: #10b981;
            --error: #ef4444;
            --radius: 20px;
            --ease: cubic-bezier(.2,.75,.25,1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            min-height: 100%;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            padding: 36px 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
            background:
                radial-gradient(ellipse at 15% 15%, rgba(0,180,216,.13), transparent 38%),
                radial-gradient(ellipse at 90% 85%, rgba(56,189,248,.12), transparent 36%),
                var(--navy);
            color: var(--text);
            font-family: "Poppins", sans-serif;
        }

        body::before,
        body::after {
            content: "";
            position: fixed;
            width: 330px;
            height: 330px;
            border-radius: 50%;
            border: 1px solid rgba(0,180,216,.12);
            pointer-events: none;
            z-index: 0;
            animation: orbit 18s linear infinite;
        }

        body::before {
            top: -170px;
            left: -120px;
        }

        body::after {
            right: -170px;
            bottom: -170px;
            animation-direction: reverse;
        }

        a {
            color: var(--bright-blue);
            text-decoration: none;
            transition: color .2s ease;
        }

        a:hover {
            color: var(--primary);
        }

        button,
        input {
            font: inherit;
        }

        button:focus-visible,
        a:focus-visible,
        input:focus-visible {
            outline: 3px solid var(--bright-blue);
            outline-offset: 3px;
        }

        .register-layout {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 1000px;
            display: grid;
            grid-template-columns: .9fr 1.1fr;
            overflow: hidden;
            border: 1px solid var(--border);
            border-radius: 26px;
            background: rgba(7,30,61,.82);
            box-shadow: 0 30px 100px rgba(0,0,0,.28);
            backdrop-filter: blur(22px);
            animation: enter .65s var(--ease) both;
        }

        .welcome-panel {
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 640px;
            padding: 38px 32px;
            background: linear-gradient(145deg, #0d3b66, #07506c 58%, #071e3d);
            border-right: 1px solid rgba(255,255,255,.08);
        }

        .welcome-panel::before,
        .welcome-panel::after {
            content: "";
            position: absolute;
            border: 1px solid rgba(0,180,216,.25);
            border-radius: 50%;
            pointer-events: none;
        }

        .welcome-panel::before {
            width: 350px;
            height: 350px;
            right: -190px;
            top: 100px;
            animation: orbit 25s linear infinite;
        }

        .welcome-panel::after {
            width: 250px;
            height: 250px;
            right: -130px;
            top: 150px;
            animation: orbit 18s linear infinite reverse;
        }

        .brand {
            position: relative;
            z-index: 1;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            color: var(--white);
            font-size: 23px;
            font-weight: 800;
            letter-spacing: -.7px;
        }

        .brand-logo {
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            overflow: hidden;
            border: 2px solid var(--primary);
            border-radius: 50%;
            background: rgba(0,180,216,.13);
            box-shadow: 0 0 18px rgba(0,180,216,.2);
            transition: transform .3s var(--ease), box-shadow .3s ease;
        }

        .brand-logo:hover {
            transform: rotate(-8deg) scale(1.08);
            box-shadow: 0 0 28px rgba(0,180,216,.42);
        }

        .brand-logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .welcome-copy {
            position: relative;
            z-index: 1;
            margin-block: 55px;
        }

        .welcome-label {
            display: inline-block;
            margin-bottom: 18px;
            padding: 7px 12px;
            border: 1px solid rgba(0,180,216,.35);
            border-radius: 30px;
            background: rgba(0,180,216,.09);
            color: var(--bright-blue);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.3px;
        }

        .welcome-copy h1 {
            max-width: 360px;
            color: var(--white);
            font-size: clamp(30px, 3.5vw, 43px);
            font-weight: 800;
            line-height: 1.22;
            letter-spacing: -1.4px;
        }

        .welcome-copy h1 span {
            color: var(--primary);
        }

        .welcome-copy p {
            max-width: 320px;
            margin-top: 18px;
            color: #c4d4e6;
            font-size: 13px;
            line-height: 1.9;
        }

        .benefit-list {
            display: grid;
            gap: 18px;
            margin-top: 30px;
        }

        .benefit-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            color: #e5edf7;
            font-size: 12px;
            line-height: 1.7;
        }

        .benefit-icon {
            flex: 0 0 36px;
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(0,180,216,.28);
            border-radius: 11px;
            background: rgba(0,180,216,.1);
            color: var(--primary);
            font-size: 18px;
            transition: transform .25s var(--ease), background .25s ease;
        }

        .benefit-item:hover .benefit-icon {
            transform: translateY(-3px) rotate(-5deg);
            background: rgba(0,180,216,.2);
        }

        .welcome-footer {
            position: relative;
            z-index: 1;
            margin-top: 32px;
            color: var(--muted);
            font-size: 10px;
        }

        .form-panel {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 42px 44px;
        }

        .form-heading {
            margin-bottom: 25px;
        }

        .form-heading h2 {
            color: var(--white);
            font-size: 28px;
            font-weight: 700;
            letter-spacing: -.8px;
        }

        .form-heading p {
            margin-top: 8px;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.8;
        }

        .alert {
            margin-bottom: 18px;
            padding: 12px 14px;
            border: 1px solid transparent;
            border-radius: 11px;
            font-size: 12px;
            line-height: 1.7;
        }

        .alert-error {
            border-color: rgba(239,68,68,.35);
            background: rgba(239,68,68,.09);
            color: #fca5a5;
        }

        .alert-success {
            border-color: rgba(16,185,129,.35);
            background: rgba(16,185,129,.09);
            color: #6ee7b7;
        }

        .field {
            min-width: 0;
            margin-bottom: 17px;
        }

        .field label,
        .field-label {
            display: block;
            margin-bottom: 8px;
            color: #dce7f5;
            font-size: 12px;
            font-weight: 600;
        }

        .field input {
            width: 100%;
            height: 47px;
            padding: 0 13px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: rgba(255,255,255,.045);
            color: var(--white);
            font-size: 12px;
            transition: border-color .2s ease, box-shadow .2s ease, background .2s ease;
        }

        .field input::placeholder {
            color: #8295ac;
        }

        .field input:hover {
            border-color: rgba(0,180,216,.45);
        }

        .field input:focus {
            border-color: var(--primary);
            background: rgba(255,255,255,.065);
            box-shadow: 0 0 0 3px rgba(0,180,216,.1);
            outline: none;
        }

        .input-wrap {
            position: relative;
        }

        .password-input {
            padding-right: 48px !important;
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 8px;
            transform: translateY(-50%);
            width: 32px;
            height: 32px;
            display: grid;
            place-items: center;
            border: 0;
            border-radius: 8px;
            background: transparent;
            color: var(--muted);
            cursor: pointer;
            transition: color .2s ease, background .2s ease, transform .2s ease;
        }

        .password-toggle:hover {
            transform: translateY(-50%) scale(1.06);
            background: rgba(0,180,216,.12);
            color: var(--primary);
        }

        .password-toggle svg {
            width: 18px;
            height: 18px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .password-hint {
            margin-top: 6px;
            color: var(--muted);
            font-size: 10px;
        }

        .role-options {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
        }

        .role-option {
            position: relative;
            min-width: 0;
        }

        .role-option input {
            position: absolute;
            width: 1px;
            height: 1px;
            opacity: 0;
        }

        .role-option label {
            min-height: 67px;
            margin: 0;
            padding: 11px;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid var(--border);
            border-radius: 11px;
            background: rgba(255,255,255,.025);
            cursor: pointer;
            transition: border-color .2s ease, background .2s ease, transform .2s ease;
        }

        .role-option label:hover {
            transform: translateY(-2px);
            border-color: rgba(0,180,216,.55);
        }

        .role-option input:checked + label {
            border-color: var(--primary);
            background: rgba(0,180,216,.1);
            box-shadow: 0 0 0 2px rgba(0,180,216,.06);
        }

        .role-option input:focus-visible + label {
            outline: 3px solid var(--bright-blue);
            outline-offset: 3px;
        }

        .role-icon {
            flex: 0 0 36px;
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: rgba(0,180,216,.12);
            color: var(--primary);
            font-size: 18px;
            transition: transform .25s var(--ease);
        }

        .role-option label:hover .role-icon {
            transform: rotate(-7deg) scale(1.08);
        }

        .role-text strong,
        .role-text small {
            display: block;
        }

        .role-text strong {
            color: var(--white);
            font-size: 11px;
        }

        .role-text small {
            margin-top: 3px;
            color: var(--muted);
            font-size: 9px;
        }

        .company-field {
            display: none;
        }

        .company-field.visible {
            display: block;
            animation: enter .25s ease both;
        }

        .submit-btn {
            width: 100%;
            min-height: 48px;
            margin-top: 7px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: 1px solid rgba(0,180,216,.4);
            border-radius: 11px;
            background: linear-gradient(110deg, #0077b6, #00b4d8);
            color: #ffffff;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0,180,216,.15);
            transition: transform .2s var(--ease), box-shadow .2s ease, filter .2s ease;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 28px rgba(0,180,216,.25);
            filter: brightness(1.08);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .submit-btn span {
            display: inline-block;
            transition: transform .2s ease;
        }

        .submit-btn:hover span {
            transform: translateX(4px);
        }

        .login-note {
            margin-top: 22px;
            color: var(--muted);
            text-align: center;
            font-size: 12px;
        }

        .login-note a {
            margin-left: 4px;
            color: var(--primary);
            font-weight: 700;
        }

        .login-note a:hover {
            color: var(--bright-blue);
            text-decoration: underline;
        }

        @keyframes enter {
            from {
                opacity: 0;
                transform: translateY(12px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes orbit {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        @media (max-width: 780px) {
            body {
                padding: 22px 14px;
            }

            .register-layout {
                max-width: 540px;
                grid-template-columns: 1fr;
            }

            .welcome-panel {
                min-height: auto;
                padding: 26px;
            }

            .welcome-copy {
                margin-block: 28px 8px;
            }

            .welcome-copy h1 {
                max-width: 440px;
                font-size: 32px;
            }

            .welcome-copy p {
                max-width: 440px;
            }

            .benefit-list,
            .welcome-footer {
                display: none;
            }

            .form-panel {
                padding: 30px 26px;
            }
        }

        @media (max-width: 430px) {
            body {
                padding: 12px;
            }

            .register-layout {
                border-radius: 18px;
            }

            .welcome-panel {
                padding: 22px;
            }

            .welcome-copy h1 {
                font-size: 29px;
            }

            .form-panel {
                padding: 25px 20px;
            }

            .form-heading h2 {
                font-size: 25px;
            }

            .role-options {
                gap: 8px;
            }

            .role-option label {
                padding: 8px;
                gap: 7px;
            }

            .role-icon {
                flex-basis: 30px;
                width: 30px;
                height: 30px;
                font-size: 15px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>

<body>
    <main class="register-layout">
        <section class="welcome-panel" aria-label="Welcome to InternPro">
            <a class="brand" href="index.php" aria-label="InternPro home">
                <span class="brand-logo">
                    <img
                        src="assets/logo.jpg"
                        alt=""
                        onerror="this.style.display='none';this.parentElement.textContent='I';"
                    >
                </span>
                <span>InternPro</span>
            </a>

            <div class="welcome-copy">
                <span class="welcome-label">YOUR CAREER STARTS HERE</span>

                <h1>
                    Turn your goals into
                    <span>opportunities.</span>
                </h1>

                <p>
                    Create your account and take the next step toward
                    discovering internships, developing your skills,
                    and building your professional future.
                </p>

                <div class="benefit-list">
                    <div class="benefit-item">
                        <div class="benefit-icon" aria-hidden="true">⌕</div>
                        <div>
                            <strong>Discover opportunities</strong>
                            <p>Find internships that match your interests.</p>
                        </div>
                    </div>

                    <div class="benefit-item">
                        <div class="benefit-icon" aria-hidden="true">◎</div>
                        <div>
                            <strong>Build your profile</strong>
                            <p>Showcase your skills and professional goals.</p>
                        </div>
                    </div>

                    <div class="benefit-item">
                        <div class="benefit-icon" aria-hidden="true">↗</div>
                        <div>
                            <strong>Track your journey</strong>
                            <p>Keep your applications organised in one place.</p>
                        </div>
                    </div>
                </div>
            </div>

            <p class="welcome-footer">
                © <?= date('Y') ?> InternPro. Start building your future.
            </p>
        </section>

        <section class="form-panel">
            <div class="form-heading">
                <h2>Create your account</h2>
                <p>Enter your details to join the InternPro community.</p>
            </div>

            <?php if ($error !== ''): ?>
                <div class="alert alert-error" role="alert" aria-live="polite">
                    <?= register_escape($error) ?>
                </div>
            <?php endif; ?>

            <?php if ($success !== ''): ?>
                <div class="alert alert-success" role="status">
                    <?= register_escape($success) ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" id="registerForm">
                <div class="field">
                    <span class="field-label">I want to register as</span>

                    <div class="role-options">
                        <div class="role-option">
                            <input
                                type="radio"
                                id="role_student"
                                name="role"
                                value="student"
                                <?= $role === 'student' ? 'checked' : '' ?>
                                required
                            >

                            <label for="role_student">
                                <span class="role-icon" aria-hidden="true">🎓</span>
                                <span class="role-text">
                                    <strong>Student</strong>
                                    <small>Find internships</small>
                                </span>
                            </label>
                        </div>

                        <div class="role-option">
                            <input
                                type="radio"
                                id="role_company"
                                name="role"
                                value="company"
                                <?= $role === 'company' ? 'checked' : '' ?>
                                required
                            >

                            <label for="role_company">
                                <span class="role-icon" aria-hidden="true">🏢</span>
                                <span class="role-text">
                                    <strong>Company</strong>
                                    <small>Post internships</small>
                                </span>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="field">
                    <label for="name">Full name</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?= register_escape($name) ?>"
                        placeholder="Enter your full name"
                        maxlength="100"
                        autocomplete="name"
                        required
                    >
                </div>

                <div class="field">
                    <label for="email">Email address</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="<?= register_escape($email) ?>"
                        placeholder="you@example.com"
                        maxlength="254"
                        autocomplete="email"
                        required
                    >
                </div>

                <div class="field company-field" id="companyField">
                    <label for="company_name">Company name</label>
                    <input
                        type="text"
                        id="company_name"
                        name="company_name"
                        value="<?= register_escape($companyName) ?>"
                        placeholder="Enter your company name"
                        maxlength="150"
                        autocomplete="organization"
                    >
                </div>

                <div class="field">
                    <label for="password">Password</label>

                    <div class="input-wrap">
                        <input
                            class="password-input"
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Create a strong password"
                            minlength="8"
                            autocomplete="new-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-target="password"
                            aria-label="Show password"
                            aria-pressed="false"
                        >
                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>

                    <p class="password-hint">
                        Use at least 8 characters.
                    </p>
                </div>

                <div class="field">
                    <label for="confirm_password">Confirm password</label>

                    <div class="input-wrap">
                        <input
                            class="password-input"
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            placeholder="Enter your password again"
                            minlength="8"
                            autocomplete="new-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-target="confirm_password"
                            aria-label="Show confirm password"
                            aria-pressed="false"
                        >
                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <button type="submit" class="submit-btn">
                    Create account <span aria-hidden="true">→</span>
                </button>
            </form>

            <p class="login-note">
                Already registered?
                <a href="login.php">Login to your account</a>
            </p>
        </section>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('registerForm');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm_password');
            const roleInputs = document.querySelectorAll('input[name="role"]');
            const companyField = document.getElementById('companyField');
            const companyInput = document.getElementById('company_name');

            /*
             * Show or hide password inputs independently.
             */
            document.querySelectorAll('.password-toggle').forEach(function (button) {
                button.addEventListener('click', function () {
                    const input = document.getElementById(button.dataset.target);
                    const showPassword = input.type === 'password';

                    input.type = showPassword ? 'text' : 'password';
                    button.setAttribute('aria-pressed', String(showPassword));

                    const fieldName = input.id === 'password'
                        ? 'password'
                        : 'confirm password';

                    button.setAttribute(
                        'aria-label',
                        (showPassword ? 'Hide ' : 'Show ') + fieldName
                    );
                });
            });

            /*
             * Require a company name only for company registrations.
             */
            function updateCompanyField() {
                const selectedRole = document.querySelector(
                    'input[name="role"]:checked'
                );

                const isCompany = selectedRole && selectedRole.value === 'company';

                companyField.classList.toggle('visible', Boolean(isCompany));
                companyInput.required = Boolean(isCompany);
            }

            roleInputs.forEach(function (input) {
                input.addEventListener('change', updateCompanyField);
            });

            updateCompanyField();

            /*
             * Validate matching passwords before submitting.
             */
            function validatePasswords() {
                confirmPassword.setCustomValidity('');

                if (
                    confirmPassword.value !== '' &&
                    password.value !== confirmPassword.value
                ) {
                    confirmPassword.setCustomValidity('Passwords do not match.');
                }
            }

            password.addEventListener('input', validatePasswords);
            confirmPassword.addEventListener('input', validatePasswords);

            form.addEventListener('submit', function (event) {
                validatePasswords();

                if (!form.checkValidity()) {
                    event.preventDefault();
                    form.reportValidity();
                }
            });
        });
    </script>
</body>
</html>
